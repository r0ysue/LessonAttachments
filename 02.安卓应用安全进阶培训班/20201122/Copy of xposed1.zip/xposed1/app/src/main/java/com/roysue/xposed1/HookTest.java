package com.roysue.xposed1;

import android.app.AndroidAppHelper;
import android.content.Context;
import android.util.Log;
import android.app.Application;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.security.auth.login.LoginException;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import fi.iki.elonen.NanoHTTPD;


public class HookTest implements IXposedHookLoadPackage {

    Object mMainActivity = null;
    public void setActivity(Object obj) {
        mMainActivity = obj;
    }
    public Object getActivity() {
        return mMainActivity;
    }


    public static Object invokeStaticMethod(String class_name,
                                            String method_name, Class[] pareTyple, Object[] pareVaules) {

        try {
            Class obj_class = Class.forName(class_name);
            Method method = obj_class.getMethod(method_name, pareTyple);
            return method.invoke(null, pareVaules);
        } catch (SecurityException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;

    }
    public static Object getFieldOjbect(String class_name, Object obj,
                                        String filedName) {
        try {
            Class obj_class = Class.forName(class_name);
            Field field = obj_class.getDeclaredField(filedName);
            field.setAccessible(true);
            return field.get(obj);
        } catch (SecurityException e) {
            e.printStackTrace();
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;

    }
    public static Field getClassField(ClassLoader classloader, String class_name,
                                      String filedName) {

        try {
            Class obj_class = classloader.loadClass(class_name);
            Field field = obj_class.getDeclaredField(filedName);
            field.setAccessible(true);
            return field;
        } catch (SecurityException e) {
            e.printStackTrace();
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;

    }
    public static ClassLoader getClassloader() {
        ClassLoader resultClassloader = null;

        Object currentActivityThread = invokeStaticMethod(
                "android.app.ActivityThread", "currentActivityThread",
                new Class[]{}, new Object[]{});
        Object mBoundApplication = getFieldOjbect(
                "android.app.ActivityThread", currentActivityThread,
                "mBoundApplication");
        Object loadedApkInfo = getFieldOjbect(
                "android.app.ActivityThread$AppBindData",
                mBoundApplication, "info");
        Application mApplication = (Application) getFieldOjbect("android.app.LoadedApk", loadedApkInfo, "mApplication");
        resultClassloader = mApplication.getClassLoader();
        return resultClassloader;
    }
    public static Object getClassFieldObject(ClassLoader classloader, String class_name, Object obj,
                                             String filedName) {

        try {
            Class obj_class = classloader.loadClass(class_name);
            Field field = obj_class.getDeclaredField(filedName);
            field.setAccessible(true);
            Object result = null;
            result = field.get(obj);
            return result;
        } catch (SecurityException e) {
            e.printStackTrace();
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return null;

    }
    public static void fart(ClassLoader clzloader) throws IOException {
        ClassLoader appClassloader = clzloader;
        List<Object> dexFilesArray = new ArrayList<Object>();
        Field pathList_Field = (Field) getClassField(appClassloader, "dalvik.system.BaseDexClassLoader", "pathList");
        Object pathList_object = getFieldOjbect("dalvik.system.BaseDexClassLoader", appClassloader, "pathList");
        Object[] ElementsArray = (Object[]) getFieldOjbect("dalvik.system.DexPathList", pathList_object, "dexElements");
        Field dexFile_fileField = null;
        try {
            dexFile_fileField = (Field) getClassField(appClassloader, "dalvik.system.DexPathList$Element", "dexFile");
        } catch (Exception e) {
            e.printStackTrace();
        }
        Class DexFileClazz = null;
        try {
            DexFileClazz = appClassloader.loadClass("dalvik.system.DexFile");
        } catch (Exception e) {
            e.printStackTrace();
        }
        Method getClassNameList_method = null;
        Method defineClass_method = null;
        Method dumpDexFile_method = null;
        Method dumpMethodCode_method = null;

        for (Method field : DexFileClazz.getDeclaredMethods()) {
            if (field.getName().equals("getClassNameList")) {
                getClassNameList_method = field;
                getClassNameList_method.setAccessible(true);
            }
            if (field.getName().equals("defineClassNative")) {
                defineClass_method = field;
                defineClass_method.setAccessible(true);
            }
            if (field.getName().equals("dumpMethodCode")) {
                dumpMethodCode_method = field;
                dumpMethodCode_method.setAccessible(true);
            }
        }
        Field mCookiefield = getClassField(appClassloader, "dalvik.system.DexFile", "mCookie");
        for (int j = 0; j < ElementsArray.length; j++) {
            Object element = ElementsArray[j];
            Object dexfile = null;
            try {
                dexfile = (Object) dexFile_fileField.get(element);
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (dexfile == null) {
                continue;
            }
            if (dexfile != null) {
                dexFilesArray.add(dexfile);
                Object mcookie = getClassFieldObject(appClassloader, "dalvik.system.DexFile", dexfile, "mCookie");
                if (mcookie == null) {
                    continue;
                }
                String[] classnames = null;
                try {
                    classnames = (String[]) getClassNameList_method.invoke(dexfile, mcookie);
                } catch (Exception e) {
                    e.printStackTrace();
                    continue;
                } catch (Error e) {
                    e.printStackTrace();
                    continue;
                }
                if (classnames != null) {
                    File file = new File("/sdcard/Download/dumpClass1122.txt");
                    if (!file.exists()) {
                        Log.d("TestFile", "Create the file:" );
                        file.createNewFile();
                    }
                    RandomAccessFile raf = new RandomAccessFile(file, "rw");
                    raf.seek(file.length());

                    for (String eachclassname : classnames) {
                        String log = "ClassNameis::" +eachclassname +"  :: "+ dumpMethodCode_method +"::"+appClassloader.toString() +"\n";
                        raf.write(log.getBytes());
                        Log.i("classes=>",log);
                    }
                    raf.close();
                }

            }
        }
        return;
    }

    public void PrintStack() {

        XposedBridge.log("Dump Stack: " + "---------------start----------------");
        Throwable ex = new Throwable();
        StackTraceElement[] stackElements = ex.getStackTrace();
        if (stackElements != null) {
            for (int i = 0; i < stackElements.length; i++) {

                XposedBridge.log("Dump Stack" + i + ": " + stackElements[i].getClassName()
                        + "----" + stackElements[i].getFileName()
                        + "----" + stackElements[i].getLineNumber()
                        + "----" + stackElements[i].getMethodName());
            }
        }
        XposedBridge.log("Dump Stack: " + "---------------over----------------");


        RuntimeException e = new RuntimeException("<Start dump Stack !>");
        e.fillInStackTrace();
        Log.i("<Dump Stack>:", "++++++++++++", e);

    }

    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam loadPackageParam) throws Throwable {
        //XposedBridge.log(loadPackageParam.processName);


        if (loadPackageParam.packageName.equals("com.cz.babySister")) {

            XposedBridge.log(" has Hooked!");
            XposedBridge.log("inner  => " + loadPackageParam.processName);

            Class ActivityThread = XposedHelpers.findClass("android.app.ActivityThread",loadPackageParam.classLoader);
            XposedBridge.hookAllMethods(ActivityThread, "performLaunchActivity", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    Object mInitialApplication = (Application) XposedHelpers.getObjectField(param.thisObject,"mInitialApplication");
                    ClassLoader finalCL = (ClassLoader) XposedHelpers.callMethod(mInitialApplication,"getClassLoader");
                    XposedBridge.log("found classload is => "+finalCL.toString());
                    Class BabyMain = (Class)XposedHelpers.callMethod(finalCL,"findClass","com.cz.babySister.activity.MainActivity");
                    XposedBridge.log("found final class is => "+BabyMain.getName().toString());
                    fart(finalCL);

                }
            });

//
//            Class clazz = loadPackageParam.classLoader.loadClass("com.cz.babySister.activity.MainActivity");
//
//            XposedHelpers.findAndHookMethod(clazz, "getJiFen", float.class, new XC_MethodHook() {
//                @Override
//                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                    super.afterHookedMethod(param);
//                    XposedBridge.log("float is "+ String.valueOf( (float) param.args[0]));
//
//                }
//            });

        }





        if (loadPackageParam.packageName.equals("com.roysue.xposed1")) {

            XposedBridge.log(" has Hooked!");
            XposedBridge.log("inner" + loadPackageParam.processName);

            Class clazz = loadPackageParam.classLoader.loadClass("com.roysue.xposed1.MainActivity");

            XposedHelpers.findAndHookMethod(clazz, "toastMessage", String.class, new XC_MethodHook() {

                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {

                    String oldText = (String) param.args[0];
                    Log.d("din not hijacked=>", oldText);

                    //param.args[0] = "test";

                    param.args[0] = "你已被劫持";
                    PrintStack();

                    //super.beforeHookedMethod(param);

                    //XposedBridge.log(" has Hooked!");


                }

                protected void afterHookedMethod(MethodHookParam param) throws Throwable {

                    Log.d("getResult is => ", (String) param.getResult());

                    param.setResult("你已被劫持2");

                }

            });

        }

//        if (loadPackageParam.packageName.equals("org.teamsik.ahe17.qualification.easy")) {
//
//            XposedBridge.log("inner"+loadPackageParam.processName);
//            Class clazz = loadPackageParam.classLoader.loadClass("org.teamsik.ahe17.qualification.Verifier");
//
//            Method encodePassword = clazz.getDeclaredMethod("encodePassword", String.class);
//            encodePassword.setAccessible(true);
//
//            byte[] p = "09042ec2c2c08c4cbece042681caf1d13984f24a".getBytes();
//            String pStr = new String((p));
//
//
//            for(int i = 999;i<10000;i++){
//
//                byte[] v = (byte[]) encodePassword.invoke(null,String.valueOf(i));
//
//                if (v.length != p.length) {
//                    break;
//
//                }
//
//                String vStr = new String(v);
//
//
//
//                if( vStr == pStr ){
//                    XposedBridge.log("Current i is => "+ String.valueOf(i));
//                }
//
//
//
//
//            }
//        }
//
//        if (loadPackageParam.packageName.equals("org.teamsik.ahe17.qualification.easy")) {
//
//            XposedBridge.log("inner"+loadPackageParam.processName);
//            Class clazz = loadPackageParam.classLoader.loadClass("org.teamsik.ahe17.qualification.Verifier");
//
//
//            Method verifyPassword = clazz.getMethod("verifyPassword", Context.class, String.class);
//            Context context = AndroidAppHelper.currentApplication();
//
//
//            for(int i = 999;i<10000;i++){
//                if((boolean)verifyPassword.invoke(null,context,String.valueOf(i))){
//                    XposedBridge.log("Current i is => "+ String.valueOf(i));
//                }
//            }
//
//        }
//
//        if (loadPackageParam.packageName.equals("org.teamsik.ahe17.qualification.easy")) {
//
//            XposedBridge.log("inner"+loadPackageParam.processName);
//            Class clazz = XposedHelpers.findClass("org.teamsik.ahe17.qualification.Verifier",loadPackageParam.classLoader);
//
//            Context context = AndroidAppHelper.currentApplication();
//
//            for(int i = 999;i<10000;i++){
//                if((boolean) XposedHelpers.callStaticMethod(clazz,"verifyPassword",context,String.valueOf(i))){
//                    XposedBridge.log("Current i is => "+ String.valueOf(i));
//                }
//            }
//        }

//
//        if (loadPackageParam.packageName.equals("org.teamsik.ahe17.qualification.easy")) {
//
//            XposedBridge.log("inner" + loadPackageParam.processName);
//            Class clazz = XposedHelpers.findClass("org.teamsik.ahe17.qualification.Verifier", loadPackageParam.classLoader);
//
//            XposedHelpers.findAndHookMethod(clazz, "encodePassword", String.class, new XC_MethodHook() {
//
//
//                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//
//                    Context context = AndroidAppHelper.currentApplication();
//
//                    for (int i = 999; i < 10000; i++) {
//                        if ((boolean) XposedHelpers.callMethod(param.thisObject, "verifyPassword", context, String.valueOf(i))) {
//                            XposedBridge.log("Current i is => " + String.valueOf(i));
//                        }
//                    }
//
//                    Log.d("getResult is => ", (String) param.getResult());
//
//                }
//
//            });
//
//        }
//
//        if (loadPackageParam.packageName.equals("org.teamsik.ahe17.qualification.easy")) {
//
//            XposedBridge.log("inner" + loadPackageParam.processName);
//            Class clazz = XposedHelpers.findClass("org.teamsik.ahe17.qualification.Verifier", loadPackageParam.classLoader);
//
//            Object Verifier = XposedHelpers.newInstance(clazz);
//
//            Context context = AndroidAppHelper.currentApplication();
//
//            for (int i = 999; i < 10000; i++) {
//                if ((boolean) XposedHelpers.callMethod(Verifier, "verifyPassword", context, String.valueOf(i))) {
//                    XposedBridge.log("Current i is => " + String.valueOf(i));
//                }
//            }
//
//
//        }
//
//
//        if (loadPackageParam.packageName.equals("org.teamsik.ahe17.qualification.easy")) {
//
//            XposedBridge.log("inner" + loadPackageParam.processName);
//
//            Constructor cons = XposedHelpers.findConstructorExact("org.teamsik.ahe17.qualification.Verifier",loadPackageParam.classLoader);
//            Object Verifier = cons.newInstance();
//
//            Context context = AndroidAppHelper.currentApplication();
//
//            for (int i = 999; i < 10000; i++) {
//                if ((boolean) XposedHelpers.callMethod(Verifier, "verifyPassword", context, String.valueOf(i))) {
//                    XposedBridge.log("Current i is => " + String.valueOf(i));
//                }
//            }
//
//
//        }

//
//        if (loadPackageParam.packageName.equals("org.teamsik.ahe17.qualification.easy")) {
//
//            XposedBridge.log("inner" + loadPackageParam.processName);
//
//            Class clazz = loadPackageParam.classLoader.loadClass("org.teamsik.ahe17.qualification.MainActivity");
//
//            XposedBridge. hookAllMethods(clazz, "onCreate",new XC_MethodHook() {
//                @Override
//                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
//                    super.afterHookedMethod(param);
//                    Object mMainAciticity = param.thisObject;
//                    XposedHelpers.callMethod(mMainAciticity,"showSuccessDialog");
//
//                }
//            });
//        }

        if (loadPackageParam.packageName.equals("com.example.demoso1")) {

            XposedBridge.log("inner" + loadPackageParam.processName);

            final Class clazz = loadPackageParam.classLoader.loadClass("com.example.demoso1.MainActivity");

            //得到对象：hook(想通过hook的方式得到一个obj的话得hook一个实例方法)
            XposedBridge.hookAllMethods(clazz, "onCreate", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    super.beforeHookedMethod(param);
                    Object mMainAciticity = param.thisObject;
                    String cipherText = (String) XposedHelpers.callMethod(mMainAciticity, "method01", "roysue");
                    String clearText = (String) XposedHelpers.callMethod(mMainAciticity, "method02", "47fcda3822cd10a8e2f667fa49da783f");
                    XposedBridge.log("Cipher text is => " + cipherText);
                    XposedBridge.log("Clear text is => " + clearText);
//                    setActivity(mMainAciticity);

                }
            });

            //xposed.newInstance获取对象
            Object newMainActivity = XposedHelpers.newInstance(clazz);
            String cipherText = (String) XposedHelpers.callMethod(newMainActivity, "method01", "roysue");
            String clearText = (String) XposedHelpers.callMethod(newMainActivity, "method02", "47fcda3822cd10a8e2f667fa49da783f");
            XposedBridge.log("Cipher text 2 is => " + cipherText);
            XposedBridge.log("Clear text 2 is => " + clearText);
            setActivity(newMainActivity);


            class App extends NanoHTTPD {

                public App() throws IOException {
                    super(8899);
                    start(NanoHTTPD.SOCKET_READ_TIMEOUT, true);
                    XposedBridge.log("\nRunning! Point your browsers to http://localhost:8899/ \n");
                }

                @Override
                public NanoHTTPD.Response serve(IHTTPSession session) {

                    Method method = session.getMethod();
                    String uri = session.getUri();
                    String RemoteIP = session.getRemoteIpAddress();
                    String RemoteHostName = session.getRemoteHostName();
                    Log.i("r0ysue nanohttpd ","Method => "+method + " ;Url => " + uri + "' ");
                    Log.i("r0ysue nanohttpd ","Remote IP  => "+RemoteIP + " ;RemoteHostName => " + RemoteHostName + "' ");

                    String paramBody = "";
                    Map<String, String> files = new HashMap<>();
                    try {
                        session.parseBody(files);
                        paramBody = session.getQueryParameterString();
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (ResponseException e) {
                        e.printStackTrace();
                    }
                    Log.i("Nano_post_param => ", paramBody);
//
//
//                    String msg = "<html><body><h1>Hello server</h1>\n";
//                    Map<String, String> parms = session.getParms();
//                    if (parms.get("username") == null) {
//                        msg += "<form action='?' method='get'>\n  <p>Your name: <input type='text' name='username'></p>\n" + "</form>\n";
//                    } else {
//                        msg += "<p>Hello, " + parms.get("username") + "!</p>";
//                    }
                    String result = "";
                    if(uri.contains("encrypt")){
                        result = (String) XposedHelpers.callMethod(getActivity(), "method01", paramBody);
                    }else if (uri.contains("decrypt")){
                        result = (String) XposedHelpers.callMethod(getActivity(), "method02", paramBody);
                    }else{
                        result = paramBody;
                    }

                    return newFixedLengthResponse(Response.Status.OK, NanoHTTPD.MIME_PLAINTEXT, result);
                }
            }
            new App();

        }
    }
}


//    android hooking list class_methods com.example.demoso1.MainActivi
//        ty
//    protected void com.example.demoso1.MainActivity.onCreate(android.os.Bundle)
//public native int com.example.demoso1.MainActivity.init()
//public native int com.example.demoso1.MainActivity.myfirstjni()
//public native java.lang.String com.example.demoso1.MainActivity.method02(java.lang.String)
//public static native java.lang.String com.example.demoso1.MainActivity.method01(java.lang.String)
//public static native java.lang.String com.example.demoso1.MainActivity.myfirstjniJNI(java.lang.String)
//public static native java.lang.String com.example.demoso1.MainActivity.stringFromJNI()
//public static native java.lang.String com.example.demoso1.MainActivity.stringFromJNI2()
//public void com.example.demoso1.MainActivity.testField()
//public void com.example.demoso1.MainActivity.testMethod()
//
//        Found 10 method(s)
