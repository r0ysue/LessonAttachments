package com.roysue.xposed1;

import android.util.Log;

import javax.security.auth.login.LoginException;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class HookTest implements IXposedHookLoadPackage {
    public void PrintStack(){

        XposedBridge.log("Dump Stack: "+ "---------------start----------------");
        Throwable ex = new Throwable();
        StackTraceElement[] stackElements = ex.getStackTrace();
        if (stackElements != null) {
            for (int i = 0; i < stackElements.length; i++) {

                XposedBridge.log("Dump Stack"+i+": "+ stackElements[i].getClassName()
                        +"----"+stackElements[i].getFileName()
                        +"----" + stackElements[i].getLineNumber()
                        +"----" +stackElements[i].getMethodName());
            }
        }
        XposedBridge.log("Dump Stack: "+ "---------------over----------------");


        RuntimeException e = new RuntimeException("<Start dump Stack !>");
        e.fillInStackTrace();
        Log.i("<Dump Stack>:", "++++++++++++", e);

    }

    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam loadPackageParam) throws Throwable {
        //XposedBridge.log(loadPackageParam.processName);

        if (loadPackageParam.packageName.equals("com.roysue.xposed1")) {

            XposedBridge.log(" has Hooked!");
            XposedBridge.log("inner"+loadPackageParam.processName);

            Class clazz = loadPackageParam.classLoader.loadClass("com.roysue.xposed1.MainActivity");

            XposedHelpers.findAndHookMethod(clazz, "toastMessage", String.class,new XC_MethodHook() {

                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {

                    String oldText = (String) param.args[0];
                    Log.d("din not hijacked=>", oldText);

                    //param.args[0] = "test";

                    param.args[0] = "你已被劫持";
                    PrintStack();

                    //super.beforeHookedMethod(param);

                    //XposedBridge.log(" has Hooked!");


                }

                protected void afterHookedMethod(MethodHookParam param) throws Throwable {

                    Log.d("getResult is => ",(String) param.getResult());

                    param.setResult("你已被劫持2");

                }

            });

        }

    }

}