window.a=function(){}
window.b=function(result){return result}
a = lmd5.hex_md5