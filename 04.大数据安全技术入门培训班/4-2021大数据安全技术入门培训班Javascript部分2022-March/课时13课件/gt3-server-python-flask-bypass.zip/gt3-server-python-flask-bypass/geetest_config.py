GEETEST_ID = "df5c92564f4d055a8e38e94183469f6f"
GEETEST_KEY = "0c4d6988ddc761e737a23fddf51acb65"
REDIS_HOST = "119.29.118.114"
REDIS_PORT = "16666"
CYCLE_TIME = 10
GEETEST_BYPASS_STATUS_KEY = "gt_server_bypass_status"
BYPASS_URL = "http://bypass.geetest.com/v1/bypass_status.php"
