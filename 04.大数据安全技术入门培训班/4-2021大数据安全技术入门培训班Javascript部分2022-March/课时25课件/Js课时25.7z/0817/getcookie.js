
function getcookie(){
    return b
}
