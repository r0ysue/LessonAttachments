import requests
import re
import execjs
from bs4 import BeautifulSoup

class spider:
    def __init__(self):
        self.session = requests.session()

    def getdata(self, url):
        headers = {
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
            'sec-ch-ua': '" Not;A Brand";v="99", "Google Chrome";v="91", "Chromium";v="91"',
            'sec-ch-ua-mobile': '?0',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-User': '?1',
            'Sec-Fetch-Dest': 'document',
            'Accept-Language': 'zh-CN,zh;q=0.9',
        }

        response = self.session.get(url, headers=headers)
        html = response.text
        if "招标项目" not in response.text:
            pattern = re.compile("<script>(.*)</script>",re.S)
            jscode = pattern.findall(response.text)[0]

            with open("env.js", "r") as f:
                envcode = f.read()

            with open("getcookie.js", "r") as f:
                getcookiecode = f.read()

            allcode = envcode + jscode + getcookiecode

            with open("allcode.js", "w") as f:
                f.write(allcode)

            ctx = execjs.compile(allcode)
            spvrscode = ctx.call("getcookie")
            print(spvrscode)
            requests.utils.add_dict_to_cookiejar(self.session.cookies, {"spvrscode": spvrscode})
            response = self.session.get('https://www.youzhicai.com/sn1/15022E858978-A7C0-4D99-A602-967A31FB4828.html', headers=headers)
            html = response.text

        soup = BeautifulSoup(html, 'lxml')
        linkList = soup.select("body > div.full-screen-con > div > div > div.projects > ul > li > a.project-name0.el")
        result = []
        for link in linkList:
            title = link.get("title")
            href = "https://www.youzhicai.com" + link.get("href")
            result.append({
                "title": title,
                "href": href
            })
        return result


if __name__ == '__main__':
    s = spider()
    AllData = []
    for i in range(1,8):
        url = f"https://www.youzhicai.com/sn{i}/15022E858978-A7C0-4D99-A602-967A31FB4828.html"
        result = s.getdata(url)
        AllData+=result
    print(AllData)
