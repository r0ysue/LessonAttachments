// ==UserScript==
// @name         hook eval
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://*/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    // Your code here...
    const _eval = eval
    eval = function(code){
        if (code.includes("debugger")){
            return null
        }
        console.log(code)
        return _eval(code)
    }
/*    eval.toString = function(){
        return _eval.toString()
    }*/
    var _toString = Function.prototype.toString
    Function.prototype.toString = function(){
        var result = _toString.apply(this, arguments)
        if (result.includes("eval")){
            return "function eval() { [native code] }"
        }
        return result
    }
})();