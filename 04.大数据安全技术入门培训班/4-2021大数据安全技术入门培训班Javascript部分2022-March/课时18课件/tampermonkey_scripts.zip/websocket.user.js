// ==UserScript==
// @name         websocket
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://*/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    window.ws = new WebSocket('ws://localhost:8010/');
    ws.onopen= function() {
        ws.send('browser started')
    };
    ws.onmessage= function(evt) {
        console.log(evt.data)
        console.log(btoa(evt.data))
    };
    ws.onerror = function(){
        console.log("连接出错");
    }

})();