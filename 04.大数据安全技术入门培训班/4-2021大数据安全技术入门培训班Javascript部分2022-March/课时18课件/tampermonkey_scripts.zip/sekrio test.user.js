// ==UserScript==
// @name         sekrio test
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://www.dtasecurity.cn:11080/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    var s = document.createElement("script")
    s.src = "https://sekiro.virjar.com/sekiro-doc/assets/sekiro_web_client.js"
    s.type = "text/javascript"
    document.body.appendChild(s);
    function startsekiro(){
        function guid() {
            function S4() {
                return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
            }

            return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
        }
        var client = new SekiroClient("ws://127.0.0.1:5620/business-demo/register?group=test&clientId=" + guid());

        client.registerAction("clientTime", function (request, resolve, reject) {
            resolve("SekiroMessage：" + new Date());
        });

        client.registerAction("executeJs", function (request, resolve, reject) {
            var code = request['code'];
            if (!code) {
                reject("need param:{code}");
                return;
            }

            code = "return " + code;

            console.log("executeJs: " + code);

            try {
                var result = new Function(code)();
                resolve(result);
            } catch (e) {
                reject("error: " + e);
            }

        });
        client.registerAction("getfingger", function (request, resolve, reject) {
            try {
                var data = fp["_0x4b9b80"]()
                var sign = fp["hash"]()
                var result = {"data":data, "sign":sign}
                resolve(result);
            } catch (e) {
                reject("error: " + e);
            }

        });
        client.registerAction("getfinggerprint", function (request, resolve, reject) {
            try {
                var fingerprint = window.getfingerprint()
                var sign = window.sign(fingerprint)
                var data = window.btoa(fingerprint)
                var result = {"data":data, "sign":sign}
                resolve(result);
            } catch (e) {
                reject("error: " + e);
            }

        });
    }
    setTimeout(startsekiro,1000)
})();