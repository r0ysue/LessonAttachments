import base64
import execjs
import requests
import hashlib
headers = {
    'Connection': 'keep-alive',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    'Accept': 'application/json, text/plain, */*',
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36',
    'Content-Type': 'application/x-www-form-urlencoded',
    'Origin': 'http://www.dtasecurity.cn:30080',
    'Referer': 'http://www.dtasecurity.cn:30080/',
    'Accept-Language': 'zh,en-US;q=0.9,en;q=0.8',
}

with open("./202106-3.js", "r") as f:
    content = f.read()
ctx = execjs.compile(content)
finger = ctx.call("getfingerprint")
print(finger)

sign = hashlib.md5(finger.encode()).hexdigest().upper()
fingerprint = base64.b64encode(finger.encode()).decode()
data = {
  'sign': sign,
  'fingerprint': fingerprint
}

response = requests.post('http://www.dtasecurity.cn:35555/subject3202106', headers=headers, data=data, verify=False)
print(response.text)
