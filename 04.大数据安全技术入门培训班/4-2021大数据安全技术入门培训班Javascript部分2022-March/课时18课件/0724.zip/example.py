__all__ = ['example']

# Don't look below, you will not understand this Python code :) I don't.

from js2py.pyjs import *
# setting scope
var = Scope( JS_BUILTINS )
set_global_object(var)

# Code follows:
var.registers(['location', 'navigator', 'window', 'getfingerprint', 'history'])
var.put('window', Js({}))
var.put('navigator', Js({'vendorSub':Js(''),'productSub':Js('20030107'),'vendor':Js('Google Inc.'),'maxTouchPoints':Js(0.0),'userActivation':Js({}),'doNotTrack':var.get(u"null"),'geolocation':Js({}),'connection':Js({}),'plugins':Js({'0':Js({'0':Js({})}),'1':Js({'0':Js({})}),'2':Js({'0':Js({}),'1':Js({})})}),'mimeTypes':Js({'0':Js({}),'1':Js({}),'2':Js({}),'3':Js({})}),'webkitTemporaryStorage':Js({}),'webkitPersistentStorage':Js({}),'hardwareConcurrency':Js(4.0),'cookieEnabled':Js(True),'appCodeName':Js('Mozilla'),'appName':Js('Netscape'),'appVersion':Js('5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36'),'platform':Js('Linux x86_64'),'product':Js('Gecko'),'userAgent':Js('Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36'),'language':Js('zh'),'languages':Js([Js('zh'), Js('en-US'), Js('en')]),'onLine':Js(True),'webdriver':Js(False),'scheduling':Js({}),'mediaCapabilities':Js({}),'permissions':Js({}),'mediaSession':Js({})}))
var.put('location', Js({'ancestorOrigins':Js({}),'href':Js('http://www.dtasecurity.cn:30080/subject/#/202106subject3'),'origin':Js('http://www.dtasecurity.cn:30080'),'protocol':Js('http:'),'host':Js('www.dtasecurity.cn:11080'),'hostname':Js('www.dtasecurity.cn'),'port':Js('11080'),'pathname':Js('/subject/###hash:#/202106subject3'),'search':Js('?url=http%3A%2F%2Fwww.dtasecurity.cn%3A30080%2Fsubject%2F%23%2F202106subject3'),'hash':Js('')}))
var.put('history', Js({'length':Js(4.0),'scrollRestoration':Js('auto'),'state':Js({'key':Js('680.400')})}))
@Js
def PyJs_anonymous_0_(this, arguments, var=var):
    var = Scope({'this':this, 'arguments':arguments}, var)
    var.registers(['e', 'a'])
    var.put('e', Js([]))
    var.put('a', var.get('e').get('push').callprop('bind', var.get('e')))
    @Js
    def PyJs_anonymous_1_(e, this, arguments, var=var):
        var = Scope({'e':e, 'this':this, 'arguments':arguments}, var)
        var.registers(['t', 'e', 'c'])
        for PyJsTemp in PyJsComma(var.get('window').delete('e'),var.get('e')):
            var.put('c', PyJsTemp)
            var.put('t', var.get('e').get(var.get('c')))
            ((var.get('t') and (Js('string')==var.get('t',throw=False).typeof())) and var.get('a')(((var.get('c')+Js(':'))+var.get('t'))))
    PyJs_anonymous_1_._set_name('anonymous')
    return PyJsComma(Js([var.get('navigator'), var.get('location'), var.get('history')]).callprop('forEach', PyJs_anonymous_1_),var.get('e').callprop('join', Js('###')))
PyJs_anonymous_0_._set_name('anonymous')
var.put('getfingerprint', PyJs_anonymous_0_)


# Add lib to the module scope
example = var.to_python()
print(example.getfingerprint())
