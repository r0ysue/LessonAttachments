// let {
//     window,
//     navigator,
//     screen,
//     location,
//     String,
//     Image,
//     document,
//     history
// } = require('./MyProxy.js');
var window = {}
var navigator = {
    "vendorSub": "",
    "productSub": "20030107",
    "vendor": "Google Inc.",
    "maxTouchPoints": 0,
    "userActivation": {},
    "doNotTrack": null,
    "geolocation": {},
    "connection": {},
    "plugins": {
        "0": {
            "0": {}
        },
        "1": {
            "0": {}
        },
        "2": {
            "0": {},
            "1": {}
        }
    },
    "mimeTypes": {
        "0": {},
        "1": {},
        "2": {},
        "3": {}
    },
    "webkitTemporaryStorage": {},
    "webkitPersistentStorage": {},
    "hardwareConcurrency": 4,
    "cookieEnabled": true,
    "appCodeName": "Mozilla",
    "appName": "Netscape",
    "appVersion": "5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36",
    "platform": "Linux x86_64",
    "product": "Gecko",
    "userAgent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36",
    "language": "zh",
    "languages": [
        "zh",
        "en-US",
        "en"
    ],
    "onLine": true,
    "webdriver": false,
    "scheduling": {},
    "mediaCapabilities": {},
    "permissions": {},
    "mediaSession": {}
}
var location = {
    "ancestorOrigins": {},
    "href": "http://www.dtasecurity.cn:30080/subject/#/202106subject3",
    "origin": "http://www.dtasecurity.cn:30080",
    "protocol": "http:",
    "host": "www.dtasecurity.cn:11080",
    "hostname": "www.dtasecurity.cn",
    "port": "11080",
    "pathname": "/subject/###hash:#/202106subject3",
    "search": "?url=http%3A%2F%2Fwww.dtasecurity.cn%3A30080%2Fsubject%2F%23%2F202106subject3",
    "hash": ""
}
var history = {
    "length": 4,
    "scrollRestoration": "auto",
    "state": {
        "key": "680.400"
    }
}
var getfingerprint = function() {
    var e = []
      , a = e.push.bind(e);
    return [navigator, location, history].forEach(function(e) {
        for (var c in delete window.e,
        e) {
            var t = e[c];
            t && "string" == typeof t && a(c + ":" + t)
        }
    }),
    e.join("###")
}
var finger = getfingerprint()
console.log(finger)

module.exports = {
    getfingerprint
}
