import time

from ws4py.client.threadedclient import WebSocketClient


class CG_Client(WebSocketClient):
    def opened(self):
        print("连接成功")
        # req = open("../a.js").read()
        self.send("Python")

    def closed(self, code, reason=None):
        print("Closed down:", code, reason)

    def received_message(self, resp):
        print("resp", resp)

    def send_message(self, content):
        while True:
            self.send(content)
            time.sleep(2)


ws = None
try:
    ws = CG_Client("ws://localhost:8010/")
    ws.connect()
    ws.send_message("12312")
    ws.run_forever()
except KeyboardInterrupt:
    ws.close()

