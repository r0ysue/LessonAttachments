import requests


def get_cookie():
    # 传入seed、ts、code代码，获取zp_stoken
    res = requests.post('http://127.0.0.1:8919/get_fingger').json()
    print(res)

if __name__ == '__main__':
    get_cookie()
