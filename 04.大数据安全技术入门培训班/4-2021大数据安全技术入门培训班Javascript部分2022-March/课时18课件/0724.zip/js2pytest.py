import time

import js2py
# add = js2py.eval_js('function add(a, b) {return a + b}')
# result = add(1, 2) + 3
# print(result)


# CryptoJS = js2py.require('crypto-js')
# data = [{'id': 1}, {'id': 2}]
# JSON = js2py.eval_js('JSON')
# ciphertext = CryptoJS.AES.encrypt(JSON.stringify(data), 'secret key 123')
# print(ciphertext.toString())
# bytes = CryptoJS.AES.decrypt(ciphertext.toString(), 'secret key 123')
# decryptedData = JSON.parse(bytes.toString(CryptoJS.enc.Utf8)).to_list()
# print(decryptedData)
#
s = time.time()
with open("./202106-3.js", "r") as f:
    content = f.read()
ctx = js2py.EvalJs()
js2py.translate_file('202106-3.js', 'example.py')
ctx.execute(content)
finger = ctx.getfingerprint()
print(finger)
print(time.time() - s)
