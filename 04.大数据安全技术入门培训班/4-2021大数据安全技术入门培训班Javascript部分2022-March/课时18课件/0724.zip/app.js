webpackJsonp([1], {
    0: function (e, a) {
    }, 1: function (e, a) {
    }, 10: function (e, a) {
    }, 11: function (e, a) {
    }, 12: function (e, a) {
    }, 13: function (e, a) {
    }, 2: function (e, a) {
    }, 3: function (e, a) {
    }, "3zXX": function (e, a) {
    }, 4: function (e, a) {
    }, "4Vh3": function (e, a) {
        e.exports = {
            modp1: {
                gen: "02",
                prime: "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a63a3620ffffffffffffffff"
            },
            modp2: {
                gen: "02",
                prime: "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece65381ffffffffffffffff"
            },
            modp5: {
                gen: "02",
                prime: "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf0598da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb9ed529077096966d670c354e4abc9804f1746c08ca237327ffffffffffffffff"
            },
            modp14: {
                gen: "02",
                prime: "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf0598da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb9ed529077096966d670c354e4abc9804f1746c08ca18217c32905e462e36ce3be39e772c180e86039b2783a2ec07a28fb5c55df06f4c52c9de2bcbf6955817183995497cea956ae515d2261898fa051015728e5a8aacaa68ffffffffffffffff"
            },
            modp15: {
                gen: "02",
                prime: "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf0598da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb9ed529077096966d670c354e4abc9804f1746c08ca18217c32905e462e36ce3be39e772c180e86039b2783a2ec07a28fb5c55df06f4c52c9de2bcbf6955817183995497cea956ae515d2261898fa051015728e5a8aaac42dad33170d04507a33a85521abdf1cba64ecfb850458dbef0a8aea71575d060c7db3970f85a6e1e4c7abf5ae8cdb0933d71e8c94e04a25619dcee3d2261ad2ee6bf12ffa06d98a0864d87602733ec86a64521f2b18177b200cbbe117577a615d6c770988c0bad946e208e24fa074e5ab3143db5bfce0fd108e4b82d120a93ad2caffffffffffffffff"
            },
            modp16: {
                gen: "02",
                prime: "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf0598da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb9ed529077096966d670c354e4abc9804f1746c08ca18217c32905e462e36ce3be39e772c180e86039b2783a2ec07a28fb5c55df06f4c52c9de2bcbf6955817183995497cea956ae515d2261898fa051015728e5a8aaac42dad33170d04507a33a85521abdf1cba64ecfb850458dbef0a8aea71575d060c7db3970f85a6e1e4c7abf5ae8cdb0933d71e8c94e04a25619dcee3d2261ad2ee6bf12ffa06d98a0864d87602733ec86a64521f2b18177b200cbbe117577a615d6c770988c0bad946e208e24fa074e5ab3143db5bfce0fd108e4b82d120a92108011a723c12a787e6d788719a10bdba5b2699c327186af4e23c1a946834b6150bda2583e9ca2ad44ce8dbbbc2db04de8ef92e8efc141fbecaa6287c59474e6bc05d99b2964fa090c3a2233ba186515be7ed1f612970cee2d7afb81bdd762170481cd0069127d5b05aa993b4ea988d8fddc186ffb7dc90a6c08f4df435c934063199ffffffffffffffff"
            },
            modp17: {
                gen: "02",
                prime: "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf0598da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb9ed529077096966d670c354e4abc9804f1746c08ca18217c32905e462e36ce3be39e772c180e86039b2783a2ec07a28fb5c55df06f4c52c9de2bcbf6955817183995497cea956ae515d2261898fa051015728e5a8aaac42dad33170d04507a33a85521abdf1cba64ecfb850458dbef0a8aea71575d060c7db3970f85a6e1e4c7abf5ae8cdb0933d71e8c94e04a25619dcee3d2261ad2ee6bf12ffa06d98a0864d87602733ec86a64521f2b18177b200cbbe117577a615d6c770988c0bad946e208e24fa074e5ab3143db5bfce0fd108e4b82d120a92108011a723c12a787e6d788719a10bdba5b2699c327186af4e23c1a946834b6150bda2583e9ca2ad44ce8dbbbc2db04de8ef92e8efc141fbecaa6287c59474e6bc05d99b2964fa090c3a2233ba186515be7ed1f612970cee2d7afb81bdd762170481cd0069127d5b05aa993b4ea988d8fddc186ffb7dc90a6c08f4df435c93402849236c3fab4d27c7026c1d4dcb2602646dec9751e763dba37bdf8ff9406ad9e530ee5db382f413001aeb06a53ed9027d831179727b0865a8918da3edbebcf9b14ed44ce6cbaced4bb1bdb7f1447e6cc254b332051512bd7af426fb8f401378cd2bf5983ca01c64b92ecf032ea15d1721d03f482d7ce6e74fef6d55e702f46980c82b5a84031900b1c9e59e7c97fbec7e8f323a97a7e36cc88be0f1d45b7ff585ac54bd407b22b4154aacc8f6d7ebf48e1d814cc5ed20f8037e0a79715eef29be32806a1d58bb7c5da76f550aa3d8a1fbff0eb19ccb1a313d55cda56c9ec2ef29632387fe8d76e3c0468043e8f663f4860ee12bf2d5b0b7474d6e694f91e6dcc4024ffffffffffffffff"
            },
            modp18: {
                gen: "02",
                prime: "ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec6f44c42e9a637ed6b0bff5cb6f406b7edee386bfb5a899fa5ae9f24117c4b1fe649286651ece45b3dc2007cb8a163bf0598da48361c55d39a69163fa8fd24cf5f83655d23dca3ad961c62f356208552bb9ed529077096966d670c354e4abc9804f1746c08ca18217c32905e462e36ce3be39e772c180e86039b2783a2ec07a28fb5c55df06f4c52c9de2bcbf6955817183995497cea956ae515d2261898fa051015728e5a8aaac42dad33170d04507a33a85521abdf1cba64ecfb850458dbef0a8aea71575d060c7db3970f85a6e1e4c7abf5ae8cdb0933d71e8c94e04a25619dcee3d2261ad2ee6bf12ffa06d98a0864d87602733ec86a64521f2b18177b200cbbe117577a615d6c770988c0bad946e208e24fa074e5ab3143db5bfce0fd108e4b82d120a92108011a723c12a787e6d788719a10bdba5b2699c327186af4e23c1a946834b6150bda2583e9ca2ad44ce8dbbbc2db04de8ef92e8efc141fbecaa6287c59474e6bc05d99b2964fa090c3a2233ba186515be7ed1f612970cee2d7afb81bdd762170481cd0069127d5b05aa993b4ea988d8fddc186ffb7dc90a6c08f4df435c93402849236c3fab4d27c7026c1d4dcb2602646dec9751e763dba37bdf8ff9406ad9e530ee5db382f413001aeb06a53ed9027d831179727b0865a8918da3edbebcf9b14ed44ce6cbaced4bb1bdb7f1447e6cc254b332051512bd7af426fb8f401378cd2bf5983ca01c64b92ecf032ea15d1721d03f482d7ce6e74fef6d55e702f46980c82b5a84031900b1c9e59e7c97fbec7e8f323a97a7e36cc88be0f1d45b7ff585ac54bd407b22b4154aacc8f6d7ebf48e1d814cc5ed20f8037e0a79715eef29be32806a1d58bb7c5da76f550aa3d8a1fbff0eb19ccb1a313d55cda56c9ec2ef29632387fe8d76e3c0468043e8f663f4860ee12bf2d5b0b7474d6e694f91e6dbe115974a3926f12fee5e438777cb6a932df8cd8bec4d073b931ba3bc832b68d9dd300741fa7bf8afc47ed2576f6936ba424663aab639c5ae4f5683423b4742bf1c978238f16cbe39d652de3fdb8befc848ad922222e04a4037c0713eb57a81a23f0c73473fc646cea306b4bcbc8862f8385ddfa9d4b7fa2c087e879683303ed5bdd3a062b3cf5b3a278a66d2a13f83f44f82ddf310ee074ab6a364597e899a0255dc164f31cc50846851df9ab48195ded7ea1b1d510bd7ee74d73faf36bc31ecfa268359046f4eb879f924009438b481c6cd7889a002ed5ee382bc9190da6fc026e479558e4475677e9aa9e3050e2765694dfc81f56e880b96e7160c980dd98edd3dfffffffffffffffff"
            }
        }
    }, 5: function (e, a) {
    }, 6: function (e, a) {
    }, "6ZSt": function (e, a) {
        e.exports = {
            "aes-128-ecb": {cipher: "AES", key: 128, iv: 0, mode: "ECB", type: "block"},
            "aes-192-ecb": {cipher: "AES", key: 192, iv: 0, mode: "ECB", type: "block"},
            "aes-256-ecb": {cipher: "AES", key: 256, iv: 0, mode: "ECB", type: "block"},
            "aes-128-cbc": {cipher: "AES", key: 128, iv: 16, mode: "CBC", type: "block"},
            "aes-192-cbc": {cipher: "AES", key: 192, iv: 16, mode: "CBC", type: "block"},
            "aes-256-cbc": {cipher: "AES", key: 256, iv: 16, mode: "CBC", type: "block"},
            aes128: {cipher: "AES", key: 128, iv: 16, mode: "CBC", type: "block"},
            aes192: {cipher: "AES", key: 192, iv: 16, mode: "CBC", type: "block"},
            aes256: {cipher: "AES", key: 256, iv: 16, mode: "CBC", type: "block"},
            "aes-128-cfb": {cipher: "AES", key: 128, iv: 16, mode: "CFB", type: "stream"},
            "aes-192-cfb": {cipher: "AES", key: 192, iv: 16, mode: "CFB", type: "stream"},
            "aes-256-cfb": {cipher: "AES", key: 256, iv: 16, mode: "CFB", type: "stream"},
            "aes-128-cfb8": {cipher: "AES", key: 128, iv: 16, mode: "CFB8", type: "stream"},
            "aes-192-cfb8": {cipher: "AES", key: 192, iv: 16, mode: "CFB8", type: "stream"},
            "aes-256-cfb8": {cipher: "AES", key: 256, iv: 16, mode: "CFB8", type: "stream"},
            "aes-128-cfb1": {cipher: "AES", key: 128, iv: 16, mode: "CFB1", type: "stream"},
            "aes-192-cfb1": {cipher: "AES", key: 192, iv: 16, mode: "CFB1", type: "stream"},
            "aes-256-cfb1": {cipher: "AES", key: 256, iv: 16, mode: "CFB1", type: "stream"},
            "aes-128-ofb": {cipher: "AES", key: 128, iv: 16, mode: "OFB", type: "stream"},
            "aes-192-ofb": {cipher: "AES", key: 192, iv: 16, mode: "OFB", type: "stream"},
            "aes-256-ofb": {cipher: "AES", key: 256, iv: 16, mode: "OFB", type: "stream"},
            "aes-128-ctr": {cipher: "AES", key: 128, iv: 16, mode: "CTR", type: "stream"},
            "aes-192-ctr": {cipher: "AES", key: 192, iv: 16, mode: "CTR", type: "stream"},
            "aes-256-ctr": {cipher: "AES", key: 256, iv: 16, mode: "CTR", type: "stream"},
            "aes-128-gcm": {cipher: "AES", key: 128, iv: 12, mode: "GCM", type: "auth"},
            "aes-192-gcm": {cipher: "AES", key: 192, iv: 12, mode: "GCM", type: "auth"},
            "aes-256-gcm": {cipher: "AES", key: 256, iv: 12, mode: "GCM", type: "auth"}
        }
    }, 7: function (e, a) {
    }, 8: function (e, a) {
    }, "8PU5": function (e, a) {
    }, "8YCc": function (e, a) {
        e.exports = {
            "2.16.840.1.101.3.4.1.1": "aes-128-ecb",
            "2.16.840.1.101.3.4.1.2": "aes-128-cbc",
            "2.16.840.1.101.3.4.1.3": "aes-128-ofb",
            "2.16.840.1.101.3.4.1.4": "aes-128-cfb",
            "2.16.840.1.101.3.4.1.21": "aes-192-ecb",
            "2.16.840.1.101.3.4.1.22": "aes-192-cbc",
            "2.16.840.1.101.3.4.1.23": "aes-192-ofb",
            "2.16.840.1.101.3.4.1.24": "aes-192-cfb",
            "2.16.840.1.101.3.4.1.41": "aes-256-ecb",
            "2.16.840.1.101.3.4.1.42": "aes-256-cbc",
            "2.16.840.1.101.3.4.1.43": "aes-256-ofb",
            "2.16.840.1.101.3.4.1.44": "aes-256-cfb"
        }
    }, 9: function (e, a) {
    }, A8l3: function (e, a) {
    }, DvjS: function (e, a) {
    }, FHEB: function (e, a) {
    }, KYqO: function (e, a) {
        e.exports = {
            name: "elliptic",
            version: "6.5.4",
            description: "EC cryptography",
            main: "lib/elliptic.js",
            files: ["lib"],
            scripts: {
                lint: "eslint lib test",
                "lint:fix": "npm run lint -- --fix",
                unit: "istanbul test _mocha --reporter=spec test/index.js",
                test: "npm run lint && npm run unit",
                version: "grunt dist && git add dist/"
            },
            repository: {type: "git", url: "git@github.com:indutny/elliptic"},
            keywords: ["EC", "Elliptic", "curve", "Cryptography"],
            author: "Fedor Indutny <fedor@indutny.com>",
            license: "MIT",
            bugs: {url: "https://github.com/indutny/elliptic/issues"},
            homepage: "https://github.com/indutny/elliptic",
            devDependencies: {
                brfs: "^2.0.2",
                coveralls: "^3.1.0",
                eslint: "^7.6.0",
                grunt: "^1.2.1",
                "grunt-browserify": "^5.3.0",
                "grunt-cli": "^1.3.2",
                "grunt-contrib-connect": "^3.0.0",
                "grunt-contrib-copy": "^1.0.0",
                "grunt-contrib-uglify": "^5.0.0",
                "grunt-mocha-istanbul": "^5.0.2",
                "grunt-saucelabs": "^9.0.1",
                istanbul: "^0.4.5",
                mocha: "^8.0.1"
            },
            dependencies: {
                "bn.js": "^4.11.9",
                brorand: "^1.1.0",
                "hash.js": "^1.0.0",
                "hmac-drbg": "^1.0.1",
                inherits: "^2.0.4",
                "minimalistic-assert": "^1.0.1",
                "minimalistic-crypto-utils": "^1.0.1"
            }
        }
    }, NHnr: function (e, a, c) {
        "use strict";
        Object.defineProperty(a, "__esModule", {value: !0});
        var t = c("7+uW"), f = {
            render: function () {
                var e = this.$createElement, a = this._self._c || e;
                return a("div", {attrs: {id: "app"}}, [a("router-view")], 1)
            }, staticRenderFns: []
        };
        var n = c("VU/8")({name: "App"}, f, !1, function (e) {
            c("3zXX")
        }, null, null).exports, d = c("/ocq"), i = {
            name: "SubjectContent", data: function () {
                return {name: "2021骞�6鏈堜唤JS閫嗗悜绗竴棰�", description: "閫氳繃hook Storage鎺ュ彛鐨勬柟寮忓畾浣嶈繕鍘熷姞瀵嗙畻娉�"}
            }, methods: {
                handleClickBtn: function () {
                    this.getEncrypt() ? alert("璇峰嬁閲嶅鐢熸垚!") : alert("鐢熸垚鎴愬姛!")
                }, getEncrypt: function () {
                    var e = window.localStorage.getItem("encrypt"), a = window.sessionStorage.getItem("encrypt");
                    return !(!e || !a) || this.Encrypt()
                }, Encrypt: function () {
                    window.localStorage.setItem("encrypt", (new Date).getTime().toString(16)), window.sessionStorage.setItem("encrypt", (new Date).getTime().toString(8))
                }
            }
        }, s = {
            render: function () {
                var e = this, a = e.$createElement, c = e._self._c || a;
                return c("div", {staticClass: "content"}, [c("h1", {staticClass: "name"}, [e._v(" " + e._s(e.name) + " ")]), e._v(" "), c("h4", [e._v(" " + e._s(e.description) + " ")]), e._v(" "), c("button", {on: {click: e.handleClickBtn}}, [e._v("鐢熸垚鍔犲瘑鍙傛暟")])])
            }, staticRenderFns: []
        };
        var r = {
            name: "subject1", components: {
                SubjectContent: c("VU/8")(i, s, !1, function (e) {
                    c("givD")
                }, "data-v-6e523bf3", null).exports
            }
        }, b = {
            render: function () {
                var e = this.$createElement, a = this._self._c || e;
                return a("div", [a("subject-content")], 1)
            }, staticRenderFns: []
        };
        var o = c("VU/8")(r, b, !1, function (e) {
            c("bQWp")
        }, "data-v-a7e9648a", null).exports, u = c("BO1k"), l = c.n(u), h = c("mtWM"), p = c.n(h), m = {
            name: "SubjectContent", data: function () {
                return {name: "2021骞�6鏈堜唤JS閫嗗悜绗簩棰�", description: "閫氳繃缂栧啓浠ｇ爜鏉� Hook XHR 瀹氫綅璇锋眰浠ｇ爜"}
            }, methods: {
                encryptdata: function () {
                    var e = String(+new Date), a = "", c = !0, t = !1, f = void 0;
                    try {
                        for (var n, d = l()(e); !(c = (n = d.next()).done); c = !0) {
                            a += n.value.codePointAt()
                        }
                    } catch (e) {
                        t = !0, f = e
                    } finally {
                        try {
                            !c && d.return && d.return()
                        } finally {
                            if (t) throw f
                        }
                    }
                    return a
                }, handleClickBtn: function () {
                    p()({
                        method: "get",
                        url: "/subject/static/test/test.json",
                        params: {data: this.encryptdata()}
                    }).then(function (e) {
                        alert(e.data)
                    }).catch(function (e) {
                        console.log(e), alert(e)
                    })
                }
            }
        }, v = {
            render: function () {
                var e = this, a = e.$createElement, c = e._self._c || a;
                return c("div", {staticClass: "content"}, [c("h1", {staticClass: "name"}, [e._v(" " + e._s(e.name) + " ")]), e._v(" "), c("h4", [e._v(" " + e._s(e.description) + " ")]), e._v(" "), c("button", {on: {click: e.handleClickBtn}}, [e._v("璇锋眰鏈嶅姟鍣�")])])
            }, staticRenderFns: []
        };
        var g = {
            name: "subject2", components: {
                SubjectContent: c("VU/8")(m, v, !1, function (e) {
                    c("DvjS")
                }, "data-v-026f8bff", null).exports
            }
        }, y = {
            render: function () {
                var e = this.$createElement, a = this._self._c || e;
                return a("div", [a("subject-content")], 1)
            }, staticRenderFns: []
        };
        var S = c("VU/8")(g, y, !1, function (e) {
            c("FHEB")
        }, "data-v-f933a30c", null).exports, k = c("uqrR"), w = c.n(k), A = {
            name: "SubjectContent", data: function () {
                return {name: "2021骞�6鏈堜唤JS閫嗗悜绗笁棰�", description: "鍦╪ode涓ā鎷熸祻瑙堝櫒鎸囩汗鐢熸垚", fingerprint: ""}
            }, methods: {
                handleClickBtn: function () {
                    var e = this.getfingerprint();
                    window.getfingerprint = this.getfingerprint
                    window.sign = this.$Encrypt.sign
                    this.fingerprint = this.$Encrypt.sign(e), p()({
                        method: "post",
                        url: "http://www.dtasecurity.cn:35555/subject3202106",
                        data: {sign: this.fingerprint, fingerprint: window.btoa(e)},
                        transformRequest: [function (e) {
                            var a = "";
                            for (var c in e) a += encodeURIComponent(c) + "=" + encodeURIComponent(e[c]) + "&";
                            return a = a.substring(0, a.lastIndexOf("&"))
                        }],
                        headers: {"Content-Type": "application/x-www-form-urlencoded"}
                    }).then(function (e) {
                        alert(e.data.msg)
                    }).catch(function (e) {
                        console.log(e), alert(e)
                    })
                }, getfingerprint: function () {
                    var e = [], a = e.push.bind(e);
                    return [navigator, location, history].forEach(function (e) {
                        for (var c in w()(window, e), e) {
                            var t = e[c];
                            t && "string" == typeof t && a(c + ":" + t)
                        }
                    }), e.join("###")
                }
            }
        }, C = {
            render: function () {
                var e = this, a = e.$createElement, c = e._self._c || a;
                return c("div", {staticClass: "content"}, [c("h1", {staticClass: "name"}, [e._v(" " + e._s(e.name) + " ")]), e._v(" "), c("h4", [e._v(" " + e._s(e.description) + " ")]), e._v(" "), c("button", {on: {click: e.handleClickBtn}}, [e._v("鐢熸垚鎸囩汗")]), e._v(" "), c("div", [e._v(" 娴忚鍣ㄦ寚绾逛负: " + e._s(e.fingerprint) + " ")])])
            }, staticRenderFns: []
        };
        var E = {
            name: "subject3", components: {
                SubjectContent: c("VU/8")(A, C, !1, function (e) {
                    c("8PU5")
                }, "data-v-2c104a55", null).exports
            }
        }, _ = {
            render: function () {
                var e = this.$createElement, a = this._self._c || e;
                return a("div", [a("subject-content")], 1)
            }, staticRenderFns: []
        };
        var x = c("VU/8")(E, _, !1, function (e) {
            c("lExw")
        }, "data-v-5ac10f39", null).exports, D = c("Xxa5"), R = c.n(D), F = c("exGp"), B = c.n(F), j = Math.PI, I = {
            name: "SlideVerify",
            props: {
                l: {type: Number, default: 42},
                r: {type: Number, default: 10},
                w: {type: Number, default: 400},
                h: {type: Number, default: 200},
                sliderText: {type: String, default: "Slide filled right"},
                accuracy: {type: Number, default: 5},
                show: {type: Boolean, default: !1},
                imgs: {
                    type: Array, default: function () {
                        return []
                    }
                },
                imgsliders: {
                    type: Array, default: function () {
                        return []
                    }
                }
            },
            data: function () {
                return {
                    containerActive: !1,
                    containerSuccess: !1,
                    containerFail: !1,
                    canvasCtx: null,
                    blockCtx: null,
                    block: null,
                    block_x: void 0,
                    block_y: void 0,
                    sid: void 0,
                    c: void 0,
                    L: this.l + 2 * this.r + 3,
                    img: void 0,
                    originX: void 0,
                    originY: void 0,
                    isMouseDown: !1,
                    sliderLeft: 0,
                    sliderMaskWidth: 0,
                    success: !1,
                    loadBlock: !0,
                    timestamp: null
                }
            },
            mounted: function () {
                window.trail = [], this.init()
            },
            methods: {
                init: function () {
                    this.initDom(), this.initImg(), this.bindEvents()
                }, initDom: function () {
                    this.block = this.$refs.block, this.canvasCtx = this.$refs.canvas.getContext("2d"), this.blockCtx = this.block.getContext("2d")
                }, initImg: function () {
                    var e = this;
                    return B()(R.a.mark(function a() {
                        return R.a.wrap(function (a) {
                            for (; ;) switch (a.prev = a.next) {
                                case 0:
                                    return a.next = 2, e.createImg().then(function (a) {
                                        var c = a.img, t = a.slider;
                                        e.loadBlock = !1, e.img = c, e.slider = t
                                    });
                                case 2:
                                case"end":
                                    return a.stop()
                            }
                        }, a, e)
                    }))()
                }, decodekey: function (e) {
                    for (var a = [], c = 0; c < e.length; c++) {
                        var t = e.charCodeAt(c);
                        a.push(66 ^ t)
                    }
                    return a
                }, draw: function (e, a, c, t) {
                    var f = this.l, n = this.r;
                    e.beginPath(), e.moveTo(a, c), e.arc(a + f / 2, c - n + 2, n, .72 * j, 2.26 * j), e.lineTo(a + f, c), e.arc(a + f + n - 2, c + f / 2, n, 1.21 * j, 2.78 * j), e.lineTo(a + f, c + f), e.lineTo(a, c + f), e.arc(a + n - 2, c + f / 2, n + .4, 2.76 * j, 1.24 * j, !0), e.lineTo(a, c), e.lineWidth = 2, e.fillStyle = "rgba(255, 255, 255, 0.7)", e.strokeStyle = "rgba(255, 255, 255, 0.7)", e.stroke(), e[t](), e.globalCompositeOperation = "destination-over"
                }, createImg: function () {
                    var e = this;
                    return B()(R.a.mark(function a() {
                        var c, t, f;
                        return R.a.wrap(function (a) {
                            for (; ;) switch (a.prev = a.next) {
                                case 0:
                                    return (c = document.createElement("img")).crossOrigin = "Anonymous", c.onload = function () {
                                        for (var a = e.decodekey(e.c), c = 0; c < a.length; c++) e.canvasCtx.drawImage(e.img, 30 * c, 0, 30, 400, 30 * a[c] / 1.5, 0, 20, 200)
                                    }, c.onerror = function () {
                                        console.log("Error")
                                    }, (t = document.createElement("img")).crossOrigin = "slider", t.onload = function () {
                                        var a = e.block_y;
                                        e.blockCtx.drawImage(t, 0, 0, t.width, t.height, 0, a, 65, 65)
                                    }, t.onerror = function () {
                                        console.log("Error")
                                    }, a.next = 10, e.getRandomImg();
                                case 10:
                                    return (f = a.sent) && (c.src = f.p1, t.src = f.p2), a.abrupt("return", {
                                        img: c,
                                        slider: t
                                    });
                                case 13:
                                case"end":
                                    return a.stop()
                            }
                        }, a, e)
                    }))()
                }, getRandomImg: function () {
                    var e = this;
                    return p.a.get("http://www.dtasecurity.cn:35555/picture", {
                        params: {
                            w: this.w,
                            h: this.h
                        }
                    }).then(function (a) {
                        if (a.data.success) return e.block_y = a.data.y, e.sid = a.data.sid, e.c = a.data.c, {
                            p1: a.data.p1,
                            p2: a.data.p2
                        };
                        throw new Error(a.data.msg)
                    }).catch(function (e) {
                        alert(e)
                    })
                }, getRandomNumberByRange: function (e, a) {
                    return Math.round(Math.random() * (a - e) + e)
                }, refresh: function () {
                    this.reset(), this.$emit("refresh")
                }, bindEvents: function () {
                    var e = this;
                    document.addEventListener("mousemove", function (a) {
                        if (!e.isMouseDown) return !1;
                        var c = parseInt(a.clientX - e.originX), t = parseInt(a.clientY - e.originY),
                            f = (new Date).getTime() - e.timestamp;
                        if (c < 0 || c + 38 >= e.w) return !1;
                        e.sliderLeft = c + "px", e.block.style.left = c + "px", e.containerActive = !0, e.sliderMaskWidth = c + "px";
                        var n = window.btoa(c + "," + t + "," + f);
                        window.trail.push(n)
                    }), document.addEventListener("mouseup", function (a) {
                        return !!e.isMouseDown && (e.isMouseDown = !1, a.clientX !== e.originX && (e.containerActive = !1, e.timestamp = +new Date - e.timestamp, void e.verify()))
                    }), document.addEventListener("mousedown", function (a) {
                        e.success || (e.originX = a.clientX, e.originY = a.clientY, e.isMouseDown = !0, e.timestamp = +new Date)
                    }), document.addEventListener("touchstart", function (a) {
                        e.success || (e.originX = a.changedTouches[0].pageX, e.originY = a.changedTouches[0].pageY, e.isMouseDown = !0, e.timestamp = +new Date)
                    }), document.addEventListener("touchmove", function (a) {
                        if (!e.isMouseDown) return !1;
                        var c = parseInt(a.changedTouches[0].pageX - e.originX),
                            t = parseInt(a.changedTouches[0].pageY - e.originY), f = (new Date).getTime() - e.timestamp;
                        if (c < 0 || c + 38 >= e.w) return !1;
                        e.sliderLeft = c + "px", e.block.style.left = c + "px", e.containerActive = !0, e.sliderMaskWidth = c + "px";
                        var n = btoa(c + "," + t + "," + f);
                        window.trail.push(n)
                    }), document.addEventListener("touchend", function (a) {
                        return !!e.isMouseDown && (e.isMouseDown = !1, a.changedTouches[0].pageX !== e.originX && (e.containerActive = !1, e.timestamp = +new Date - e.timestamp, void e.verify()))
                    })
                }, verify_by_server: function (e) {
                    var a = this;
                    return B()(R.a.mark(function c() {
                        return R.a.wrap(function (c) {
                            for (; ;) switch (c.prev = c.next) {
                                case 0:
                                    return c.abrupt("return", p()({
                                        method: "post",
                                        url: "http://www.dtasecurity.cn:35555/slide",
                                        data: {sid: a.sid, trail: e}
                                    }).then(function (e) {
                                        return e
                                    }));
                                case 1:
                                case"end":
                                    return c.stop()
                            }
                        }, c, a)
                    }))()
                }, verify: function () {
                    var e = this, a = window.trail.join("*");
                    this.verify_by_server(a).then(function (a) {
                        alert(a.data.msg), a.data.spliced ? 200 === a.data.code ? (e.containerSuccess = !0, e.success = !0, e.$emit("success", e.timestamp)) : (e.containerFail = !0, e.$emit("again")) : (e.containerFail = !0, e.$emit("fail"), setTimeout(function () {
                            e.reset()
                        }, 1e3))
                    }).catch(function (e) {
                        alert("Network Error")
                    }), window.trail = [], this.sid = null, this.c = null
                }, reset: function () {
                    var e = this;
                    return B()(R.a.mark(function a() {
                        var c, t, f;
                        return R.a.wrap(function (a) {
                            for (; ;) switch (a.prev = a.next) {
                                case 0:
                                    return e.success = !1, e.containerActive = !1, e.containerSuccess = !1, e.containerFail = !1, e.sliderLeft = 0, e.block.style.left = 0, e.sliderMaskWidth = 0, c = e.w, t = e.h, e.canvasCtx.clearRect(0, 0, c, t), e.blockCtx.clearRect(0, 0, c, t), e.block.width = c, a.next = 13, e.getRandomImg();
                                case 13:
                                    (f = a.sent) && (e.img.src = f.p1, e.slider.src = f.p2), e.$emit("fulfilled");
                                case 16:
                                case"end":
                                    return a.stop()
                            }
                        }, a, e)
                    }))()
                }
            }
        }, H = {
            render: function () {
                var e = this, a = e.$createElement, c = e._self._c || a;
                return c("div", {
                    staticClass: "slide-verify",
                    style: {width: e.w + "px"},
                    attrs: {id: "slideVerify", onselectstart: "return false;"}
                }, [c("div", {class: {"slider-verify-loading": e.loadBlock}}), e._v(" "), c("canvas", {
                    ref: "canvas",
                    attrs: {width: e.w, height: e.h}
                }), e._v(" "), e.show ? c("div", {
                    staticClass: "slide-verify-refresh-icon",
                    on: {click: e.refresh}
                }) : e._e(), e._v(" "), c("canvas", {
                    ref: "block",
                    staticClass: "slide-verify-block",
                    attrs: {width: e.w, height: e.h}
                }), e._v(" "), c("div", {
                    staticClass: "slide-verify-slider",
                    class: {
                        "container-active": e.containerActive,
                        "container-success": e.containerSuccess,
                        "container-fail": e.containerFail
                    }
                }, [c("div", {
                    staticClass: "slide-verify-slider-mask",
                    style: {width: e.sliderMaskWidth}
                }, [c("div", {
                    staticClass: "slide-verify-slider-mask-item",
                    style: {left: e.sliderLeft}
                }, [c("div", {staticClass: "slide-verify-slider-mask-item-icon"})])]), e._v(" "), c("span", {staticClass: "slide-verify-slider-text"}, [e._v(e._s(e.sliderText))])])])
            }, staticRenderFns: []
        };
        var M = {
            name: "App", data: function () {
                return {text: "鍚戝彸婊戝姩->", accuracy: 5}
            }, methods: {
                onSuccess: function (e) {
                }, onFail: function () {
                }, onRefresh: function () {
                    this.msg = ""
                }, onFulfilled: function () {
                }, onAgain: function () {
                    alert("妫€娴嬪埌闈炰汉涓烘搷浣滅殑鍝︼紒"), this.handleClick()
                }, handleClick: function () {
                    this.$refs.slideblock.reset(), this.msg = ""
                }
            }, components: {
                SlideVerify: c("VU/8")(I, H, !1, function (e) {
                    c("lUNb")
                }, "data-v-21278ee8", null).exports
            }
        }, T = {
            render: function () {
                var e = this, a = e.$createElement, c = e._self._c || a;
                return c("div", {attrs: {id: "app"}}, [c("slide-verify", {
                    ref: "slideblock",
                    attrs: {"slider-text": e.text, imgs: e.imgs, accuracy: e.accuracy},
                    on: {
                        success: e.onSuccess,
                        again: e.onAgain,
                        fulfilled: e.onFulfilled,
                        fail: e.onFail,
                        refresh: e.onRefresh
                    }
                }), e._v(" "), c("button", {staticClass: "btn", on: {click: e.handleClick}}, [e._v("鍒锋柊鍥剧墖")])], 1)
            }, staticRenderFns: []
        };
        var W = c("VU/8")(M, T, !1, function (e) {
            c("lgFt")
        }, "data-v-255b8ba8", null).exports, $ = {
            render: function () {
                var e = this.$createElement, a = this._self._c || e;
                return a("div", {staticClass: "home"}, [a("h1", [this._v(this._s(this.title))])])
            }, staticRenderFns: []
        };
        var X = c("VU/8")({
            name: "Home", data: function () {
                return {title: "bigdata Subject"}
            }
        }, $, !1, function (e) {
            c("A8l3")
        }, "data-v-14ba39e6", null).exports;
        t.a.use(d.a);
        var U = new d.a({
            routes: [{path: "/", name: "Home", component: X}, {
                path: "/202106subject1",
                name: "202106subject1",
                component: o
            }, {path: "/202106subject2", name: "202106subject2", component: S}, {
                path: "/202106subject3",
                name: "202106subject3",
                component: x
            }, {path: "/slide", name: "slide", component: W}]
        }), V = c("Av7u"), L = c.n(V), N = function (e) {
            return L.a.MD5(e).toString().toUpperCase()
        };
        var Y = {
            sign: function (e) {
                return N(e)
            }
        };
        t.a.prototype.$Encrypt = Y, t.a.config.productionTip = !1, new t.a({
            el: "#app",
            router: U,
            components: {App: n},
            template: "<App/>"
        })
    }, QDfD: function (e, a) {
        e.exports = {
            "1.3.132.0.10": "secp256k1",
            "1.3.132.0.33": "p224",
            "1.2.840.10045.3.1.1": "p192",
            "1.2.840.10045.3.1.7": "p256",
            "1.3.132.0.34": "p384",
            "1.3.132.0.35": "p521"
        }
    }, bQWp: function (e, a) {
    }, ejIc: function (e, a) {
        e.exports = {
            sha224WithRSAEncryption: {sign: "rsa", hash: "sha224", id: "302d300d06096086480165030402040500041c"},
            "RSA-SHA224": {sign: "ecdsa/rsa", hash: "sha224", id: "302d300d06096086480165030402040500041c"},
            sha256WithRSAEncryption: {sign: "rsa", hash: "sha256", id: "3031300d060960864801650304020105000420"},
            "RSA-SHA256": {sign: "ecdsa/rsa", hash: "sha256", id: "3031300d060960864801650304020105000420"},
            sha384WithRSAEncryption: {sign: "rsa", hash: "sha384", id: "3041300d060960864801650304020205000430"},
            "RSA-SHA384": {sign: "ecdsa/rsa", hash: "sha384", id: "3041300d060960864801650304020205000430"},
            sha512WithRSAEncryption: {sign: "rsa", hash: "sha512", id: "3051300d060960864801650304020305000440"},
            "RSA-SHA512": {sign: "ecdsa/rsa", hash: "sha512", id: "3051300d060960864801650304020305000440"},
            "RSA-SHA1": {sign: "rsa", hash: "sha1", id: "3021300906052b0e03021a05000414"},
            "ecdsa-with-SHA1": {sign: "ecdsa", hash: "sha1", id: ""},
            sha256: {sign: "ecdsa", hash: "sha256", id: ""},
            sha224: {sign: "ecdsa", hash: "sha224", id: ""},
            sha384: {sign: "ecdsa", hash: "sha384", id: ""},
            sha512: {sign: "ecdsa", hash: "sha512", id: ""},
            "DSA-SHA": {sign: "dsa", hash: "sha1", id: ""},
            "DSA-SHA1": {sign: "dsa", hash: "sha1", id: ""},
            DSA: {sign: "dsa", hash: "sha1", id: ""},
            "DSA-WITH-SHA224": {sign: "dsa", hash: "sha224", id: ""},
            "DSA-SHA224": {sign: "dsa", hash: "sha224", id: ""},
            "DSA-WITH-SHA256": {sign: "dsa", hash: "sha256", id: ""},
            "DSA-SHA256": {sign: "dsa", hash: "sha256", id: ""},
            "DSA-WITH-SHA384": {sign: "dsa", hash: "sha384", id: ""},
            "DSA-SHA384": {sign: "dsa", hash: "sha384", id: ""},
            "DSA-WITH-SHA512": {sign: "dsa", hash: "sha512", id: ""},
            "DSA-SHA512": {sign: "dsa", hash: "sha512", id: ""},
            "DSA-RIPEMD160": {sign: "dsa", hash: "rmd160", id: ""},
            ripemd160WithRSA: {sign: "rsa", hash: "rmd160", id: "3021300906052b2403020105000414"},
            "RSA-RIPEMD160": {sign: "rsa", hash: "rmd160", id: "3021300906052b2403020105000414"},
            md5WithRSAEncryption: {sign: "rsa", hash: "md5", id: "3020300c06082a864886f70d020505000410"},
            "RSA-MD5": {sign: "rsa", hash: "md5", id: "3020300c06082a864886f70d020505000410"}
        }
    }, givD: function (e, a) {
    }, lExw: function (e, a) {
    }, lUNb: function (e, a) {
    }, lgFt: function (e, a) {
    }
}, ["NHnr"]);
