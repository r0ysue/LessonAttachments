import time

import execjs.runtime_names
s = time.time()
with open("./202106-3.js", "r") as f:
    content = f.read()
ctx = execjs.compile(content)
finger = ctx.call("getfingerprint")
print(finger)
print(time.time() - s)
