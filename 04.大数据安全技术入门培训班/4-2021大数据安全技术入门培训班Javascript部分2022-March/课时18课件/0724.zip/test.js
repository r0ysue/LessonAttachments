navigator = {}
location = {}
history = {}
function getfingerprint() {
    var e = []
      , a = e.push.bind(e);
    return [navigator, location, history].forEach(function(e) {
        for (var c in e) {
            var t = e[c];
            t && "string" == typeof t && a(c + ":" + t)
        }
    }),
    e.join("###")
}
console.log(getfingerprint())
