import requests
params = {
    "group": "test",  #接口名称
    "action": "getfinggerprint",  #注册的服务名
}
res = requests.get("http://127.0.0.1:5620/business-demo/invoke",params= params)
print(res.text)
