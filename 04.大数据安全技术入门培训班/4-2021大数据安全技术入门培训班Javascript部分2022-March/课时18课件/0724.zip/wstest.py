from wsclient import ws

ws.send_message("123")
