// ==UserScript==
// @name         hook xmlhttprequest
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://*/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none

// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
var keys = Object.getOwnPropertyNames(XMLHttpRequest.prototype)
for (let i = 0; i < keys.length; i++) {
    if (keys[i] === "send" ||
        keys[i] === "open" &&
        typeof XMLHttpRequest.prototype[keys[i]] === "function"){
        console.log(keys[i])
        window["_"+keys[i]]= XMLHttpRequest.prototype[keys[i]]
        XMLHttpRequest.prototype[keys[i]] = function (){
            debugger;
            console.log(arguments)
            return window["_"+keys[i]].apply(this, arguments)
        }
    }
}

})();