// ==UserScript==
// @name         hook storage
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://*/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...
    var _setItem = Storage.prototype.setItem
    Storage.prototype.setItem = function(key ,value){
        console.log(this,key, value)
        return _setItem.call(this,key, value)
    }
})();