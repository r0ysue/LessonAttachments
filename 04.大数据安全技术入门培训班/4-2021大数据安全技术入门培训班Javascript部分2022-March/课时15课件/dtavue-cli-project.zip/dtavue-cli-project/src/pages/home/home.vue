<template>
  <div>
      <h1>{{ title }}</h1>
  </div>

</template>

<script>
export default {
  name: 'home',
  data: function () {
    return {
      title: 'DTA'
    }
  }
}
</script>

<style scoped>
h1{
  font-weight: normal;
  font-size: 60px;
}
</style>
