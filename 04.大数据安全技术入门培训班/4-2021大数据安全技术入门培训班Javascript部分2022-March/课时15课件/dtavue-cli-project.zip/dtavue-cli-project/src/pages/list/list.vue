<template>
  <div>
    <button @click='handleclick'>click me</button>
  </div>
</template>

<script>
export default {
  name: 'list',
  methods: {
    handleclick () {
      alert('hello dta')
    }
  }
}
</script>

<style scoped>

</style>
