let {
    window,
    navigator,
    screen,
    location,
    Image,
    document,
} = require('./MyProxy.js');

const _0x57a7 = ['_0x2ddb76', '_0x449894', '172220xZeecZ', '_0x24c517', '_0x3f7bec', 'slice', 'target', 'bindEvents', '_0x3f10c4', 'call', '_0x4d474c', '_0x2d8905', 'width', '_0x18143d', '_0x1799b5', '_0x218cdb', '_0x556f16', '_0x16fbfc', '-mask-item', '_0x64ddc', '2|0|1|4|3', 'charAt', '_0x6f1942', '\x20div\x20>\x20div', '3|2|1|6|0|', '_0xcd72b6', 'prototype', '_0x1516fd', '_0x49f4fe', 'push', '2|4|3|1|5|', '_0x5040ec', 'length', 'left', 'gbKB=', 'SxleoQp02M', 'unSCU', '1641027OaimBY', '32RYWBRR', 'mouseup', '_0x29ef3c', 'stener', 'addEventLi', '_0x44c54d', '_0x41abe2', '_0xb8687a', '_0x4c5d03', '_0x10933c', 'MtYqS', '_0x256244', '_0x46ebc6', '_0x5127e8', 'pageY', '_0x8ac94c', '1483562UZXwAU', '_0xa33447', '5|4', '_0x5ba68e', '_0x44fdcf', '_0x1355cf', '_0x2ff68b', '_0x5d5817', 'start', 'twV9Nd57qG', 'reload', '_0x5ad6b2', '1nIenzm', 'PVhmC', '_0x3bc5ef', '_0x3e5db0', '_0x318e8e', '_0x441b2d', '_0x188357', '306107lOqHwE', 'JHrCELycAz', 'FliWd', 'ify-slider', 'tor', '658251ggaqoj', 'split', 'querySelec', 'className', '_0x3b0a57', '.slide-ver', '6|0|5|1', '_0x2c89b9', '_0x5a5a0e', '_0x288e71', 'clientX', '_0x39b26d', '_0x3fba9d', 'WvvVy', '_0x422805', '_0x433fd6', 'pageX', '_0x10753b', '_0x1a8dc3', '_0x12f7e4', '#slideVeri', 'replace', '3|2|8|7|4|', 'touchmove', 'verify', '_0x5c3eb5', '_0x30cac0', 'join', '_0x126db8', '_0x1b4b78', 'DTA2021#', 'process', 'XmYj3u1Pnv', '_0x3682ba', '_0x18a4c4', 'ches', 'qxHkG', 'indexOf', 'touchstart', '_0x371e68', 'mousedown', '_0x226d4c', '/a6DfO+kW4', 'changedTou', '_0x9f916a', 'charCodeAt', '_tl', '_0x475baa', '_0x1a58ad', '_0x543d00', '13602DISgjb', '_0x29f896', '_0x59330d', '_0x4fd937', '_0x1cefcc', 'ify-block', '_0x178335', '_0x4b3f22', '_0x287183', 'isIZUF8ThR', '-mask', '_0x4c0a00', '_0x1b2ad1', 'wcDSj', '543698QcDXFB', '2LumIyv', '1|4', 'NHBJk', 'fromCharCo', '6|0', 'app', '_0x1479a9', 'style', 'getTime', '_0x2ffaa9', '_0x447c96', 'touchend', '_0x4102cd', 'fy\x20>\x20div\x20>', '_0x35e0f1'];

function _0x3462(_0x48e4e, _0xe715a5) {
  return _0x3462 = function (_0x7f5512, _0x1a605c) {
    _0x7f5512 = _0x7f5512 - (0x1 * 0xaa2 + -0x2bb * -0x7 + -0x1c4b);
    let _0x2e3675 = _0x57a7[_0x7f5512];
    return _0x2e3675;
  }, _0x3462(_0x48e4e, _0xe715a5);
}

const _0xe854f9 = _0x3462;
(function (_0x5d8f08, _0x215a76) {
  const _0x20fa16 = _0x3462;
  while (!![]) {
    try {
      const _0x346121 = -parseInt(_0x20fa16('0x195')) * -parseInt(_0x20fa16('0x1ed')) + -parseInt(_0x20fa16(0x1a6)) + parseInt(_0x20fa16('0x1f2')) + parseInt(_0x20fa16(0x1da)) + parseInt(_0x20fa16('0x1ca')) * parseInt(_0x20fa16(0x186)) + -parseInt(_0x20fa16('0x1c9')) + parseInt(_0x20fa16('0x194')) * -parseInt(_0x20fa16(0x1e6));
      if (_0x346121 === _0x215a76) break; else _0x5d8f08['push'](_0x5d8f08['shift']());
    } catch (_0x3e10d4) {
      _0x5d8f08['push'](_0x5d8f08['shift']());
    }
  }
}(_0x57a7, -0x87523 + 0x6d84a + 0xe5033));

function DTASlider() {
}

DTASlider[_0xe854f9('0x1be')]['_0x371e68'] = new Date()[_0xe854f9('0x19d')](), DTASlider[_0xe854f9('0x1be')][_0xe854f9('0x1e4')] = function () {
  const _0x57412f = _0xe854f9, _0x4b86bc = {};
  _0x4b86bc['_0x26c7cc'] = _0x57412f(0x182);
  const _0x36b3ee = _0x4b86bc;
  this[_0x36b3ee['_0x26c7cc']] = [], this[_0x57412f(0x1d1)] = ![];
}, DTASlider['prototype'][_0xe854f9('0x1e2')] = function () {
  const _0x451de9 = _0xe854f9, _0x2fd705 = {};
  _0x2fd705[_0x451de9('0x203')] = _0x451de9(0x182), _0x2fd705[_0x451de9('0x19b')] = _0x451de9(0x1ab);
  const _0x4438a9 = _0x2fd705;
  this[_0x4438a9[_0x451de9(0x203)]] = [], this[_0x451de9(0x1d1)] = ![], this[_0x4438a9[_0x451de9(0x19b)]]();
}, DTASlider[_0xe854f9(0x1be)]['process'] = function () {
  const _0x5e3569 = _0xe854f9, _0x2d485a = {
    '_0x288e71': _0x5e3569(0x1a9),
    '_0x39b26d': _0x5e3569('0x1ad'),
    '_0x1516fd': function (_0x250053, _0x14f084) {
      return _0x250053(_0x14f084);
    }
  };
  let _0x5834b3 = [][_0x2d485a[_0x5e3569(0x1fb)]][_0x2d485a[_0x5e3569('0x1fd')]](arguments),
    _0x648b37 = this['_0x24c517']();
  this["_tl"][_0x5e3569(0x1c1)](_0x2d485a[_0x5e3569('0x1bf')](_0x648b37, _0x2d485a[_0x5e3569(0x1bf)](encodeURIComponent, _0x5834b3[_0x5e3569('0x20d')](','))));
}, DTASlider[_0xe854f9(0x1be)]['_0x8ac94c'] = function (_0xcfd4c9) {
  const _0x21a9cb = _0xe854f9, _0x12a1b1 = {};
  _0x12a1b1['_0x5ba68e'] = 'fromCharCo' + 'de', _0x12a1b1[_0x21a9cb(0x20b)] = _0x21a9cb('0x1ad'), _0x12a1b1[_0x21a9cb(0x1b3)] = function (_0xd24490, _0x2857c4) {
    return _0xd24490 + _0x2857c4;
  };
  const _0x44d64c = _0x12a1b1;
  return String[_0x44d64c[_0x21a9cb(0x1dd)]][_0x44d64c[_0x21a9cb(0x20b)]](String, _0x44d64c['_0x218cdb'](_0xcfd4c9, 0x7c6 + 0x124f + 0x1 * -0x19b1));
}, DTASlider[_0xe854f9(0x1be)][_0xe854f9(0x19a)] = function () {
  const _0x5cd2a6 = _0xe854f9, _0x21683d = {};
  _0x21683d['_0x287183'] = function (_0x398164, _0x4005df) {
    return _0x398164 + _0x4005df;
  };
  const _0x326a36 = _0x21683d,
    _0x1a0ab9 = _0x326a36[_0x5cd2a6(0x18e)](_0x5cd2a6(0x210), this['_tl'][_0x5cd2a6(0x20d)]('*'));
  window[_0x5cd2a6(0x20a)](_0x1a0ab9);
}, DTASlider[_0xe854f9('0x1be')][_0xe854f9(0x1a7)] = function () {
  const _0x522b2b = _0xe854f9, _0x226b6e = {
    '_0x30cac0': function (_0xce0255, _0x273b19) {
      return _0xce0255 & _0x273b19;
    },
    '_0x55b408': function (_0x40589b, _0x5926f0) {
      return _0x40589b + _0x5926f0;
    },
    '_0x46ebc6': function (_0x16fafc, _0x415630) {
      return _0x16fafc + _0x415630;
    },
    '_0x5d5817': function (_0x480a11, _0x35f810) {
      return _0x480a11 | _0x35f810;
    },
    '_0x59330d': function (_0x3e556d, _0x4ac992) {
      return _0x3e556d << _0x4ac992;
    },
    '_0x2ff68b': function (_0x8dda5c, _0x4f90aa) {
      return _0x8dda5c >> _0x4f90aa;
    },
    '_0x1cefcc': function (_0x1d437a, _0x334732) {
      return _0x1d437a(_0x334732);
    },
    '_0x4102cd': function (_0xc65735, _0x587beb) {
      return _0xc65735 | _0x587beb;
    },
    '_0x10933c': function (_0x184d0c, _0x509b73) {
      return _0x184d0c << _0x509b73;
    },
    '_0x4c0a00': function (_0x39a3aa, _0x254a04) {
      return _0x39a3aa & _0x254a04;
    },
    '_0x447c96': function (_0xf8f690, _0x3b533f) {
      return _0xf8f690 >> _0x3b533f;
    },
    '_0x3f7bec': function (_0x186ed0, _0x3ed92d) {
      return _0x186ed0 << _0x3ed92d;
    },
    '_0x40af5a': function (_0x3f53d5, _0x283868) {
      return _0x3f53d5 & _0x283868;
    },
    '_0x3b29f4': _0x522b2b('0x1e7'),
    '_0x18143d': '5|3|2|6|0|' + _0x522b2b(0x196),
    '_0x29ef3c': function (_0x43de28, _0x1e44b3) {
      return _0x43de28 & _0x1e44b3;
    },
    '_0x449894': function (_0x391f5c, _0x3d8009) {
      return _0x391f5c << _0x3d8009;
    },
    '_0x2ffaa9': function (_0x5c99d3, _0x115d5d) {
      return _0x5c99d3 < _0x115d5d;
    },
    '_0xd11445': _0x522b2b('0x174') + _0x522b2b('0x18f') + _0x522b2b('0x17e') + _0x522b2b(0x1ee) + _0x522b2b(0x1c7) + _0x522b2b(0x1e3) + _0x522b2b(0x1c6)
  };
  return function (_0x59e12a) {
    const _0x343e98 = _0x522b2b, _0x36877e = {
      '_0xa33447': function (_0x192590, _0x4bd477) {
        const _0x522ec7 = _0x3462;
        return _0x226b6e[_0x522ec7('0x1a1')](_0x192590, _0x4bd477);
      },
      '_0x57482f': function (_0xf15e1e, _0x432bd9) {
        return _0x226b6e['_0x10933c'](_0xf15e1e, _0x432bd9);
      },
      '_0x16fbfc': function (_0x25e933, _0x2791dc) {
        return _0x25e933 != _0x2791dc;
      },
      '_0x22f745': function (_0x5074f7, _0x389a88) {
        const _0x52bb4f = _0x3462;
        return _0x226b6e[_0x52bb4f('0x1a8')](_0x5074f7, _0x389a88);
      },
      '_0x1799b5': function (_0x3d6edd, _0x29273f) {
        return _0x226b6e['_0x40af5a'](_0x3d6edd, _0x29273f);
      },
      '_0x44fdcf': function (_0x1d36da, _0x4c8a91) {
        return _0x1d36da | _0x4c8a91;
      },
      '_0x5a5a0e': function (_0x1eae67, _0x1ffed3) {
        const _0x5edd01 = _0x3462;
        return _0x226b6e[_0x5edd01(0x19f)](_0x1eae67, _0x1ffed3);
      },
      '_0x5127e8': _0x226b6e['_0x3b29f4'],
      '_0x496422': _0x226b6e[_0x343e98('0x1b1')],
      '_0x2a3ff7': function (_0x39cc7a, _0x1ff903) {
        return _0x226b6e['_0x3f7bec'](_0x39cc7a, _0x1ff903);
      },
      '_0x4d474c': function (_0x262ce8, _0x468cf9) {
        const _0x5c16f6 = _0x343e98;
        return _0x226b6e[_0x5c16f6('0x1cc')](_0x262ce8, _0x468cf9);
      },
      '_0x2ddb76': function (_0x4bd01d, _0x28c90d) {
        return _0x4bd01d != _0x28c90d;
      },
      '_0x2d8905': function (_0x20cd95, _0x4291a8) {
        const _0x1d7c94 = _0x343e98;
        return _0x226b6e[_0x1d7c94('0x1a5')](_0x20cd95, _0x4291a8);
      },
      '_0x1a3296': function (_0x2eaa41, _0x440e6f) {
        const _0x8c5a11 = _0x343e98;
        return _0x226b6e[_0x8c5a11('0x19e')](_0x2eaa41, _0x440e6f);
      }
    };
    let _0x430729 = {
      '_0x64ddc': _0x226b6e['_0xd11445'], 'encode': function (_0x7b546a) {
        const _0x36a938 = _0x343e98;
        if (!_0x7b546a) return !(-0x20c9 + 0xe5d + 0x35 * 0x59);
        var _0x200f40 = '', _0x45946f, _0x3a3f7a, _0x5d70e9, _0x55d3d7, _0x40145f, _0x5ca8f1, _0x3b82a0,
          _0x588eb4 = -0x2564 + 0x7 * -0x532 + -0x49c2 * -0x1;
        do {
          const _0x1e9472 = (_0x36a938(0x208) + _0x36a938(0x1f8))[_0x36a938('0x1f3')]('|');
          let _0xb09342 = 0x1 * -0x1673 + -0x1 * 0xf97 + -0x657 * -0x6;
          while (!![]) {
            switch (_0x1e9472[_0xb09342++]) {
              case'0':
                _0x3b82a0 = _0x226b6e[_0x36a938(0x20c)](-0x12ea + -0x399 + -0xb61 * -0x2, _0x5d70e9);
                continue;
              case'1':
                _0x200f40 += _0x226b6e['_0x55b408'](_0x226b6e[_0x36a938(0x1d6)](this['_0x64ddc'][_0x36a938('0x1b9')](_0x55d3d7), this[_0x36a938('0x1b7')][_0x36a938(0x1b9)](_0x40145f)), this['_0x64ddc'][_0x36a938('0x1b9')](_0x5ca8f1)) + this['_0x64ddc'][_0x36a938(0x1b9)](_0x3b82a0);
                continue;
              case'2':
                _0x3a3f7a = _0x7b546a[_0x36a938(0x181)](_0x588eb4++);
                continue;
              case'3':
                _0x45946f = _0x7b546a[_0x36a938('0x181')](_0x588eb4++);
                continue;
              case'4':
                _0x40145f = _0x226b6e[_0x36a938('0x1e1')](_0x226b6e[_0x36a938('0x188')](_0x226b6e['_0x30cac0'](-0x719 + -0x9e * -0xb + 0x52, _0x45946f), -0x17d * 0x7 + 0x1e43 * 0x1 + -0x13d4), _0x226b6e[_0x36a938('0x1e0')](_0x3a3f7a, -0xa5a + 0x2340 + -0x27d * 0xa));
                continue;
              case'5':
                if (_0x226b6e[_0x36a938('0x18a')](isNaN, _0x3a3f7a)) _0x5ca8f1 = _0x3b82a0 = -0x2662 * -0x1 + -0xc16 + -0x1a0c; else {
                  if (_0x226b6e['_0x1cefcc'](isNaN, _0x5d70e9)) _0x3b82a0 = -0x174 + -0xf3b + 0x10ef;
                }
                continue;
              case'6':
                _0x5ca8f1 = _0x226b6e[_0x36a938('0x1a1')](_0x226b6e[_0x36a938('0x1d3')](_0x226b6e[_0x36a938(0x191)](0x1 * 0x1da5 + 0x236d * 0x1 + 0xbb * -0x59, _0x3a3f7a), -0x9e + -0x2308 + 0x23a8), _0x226b6e[_0x36a938('0x1e0')](_0x5d70e9, -0x1aa3 + 0x11d4 + 0x8d5));
                continue;
              case'7':
                _0x55d3d7 = _0x226b6e[_0x36a938('0x19f')](_0x45946f, 0x1d32 + 0xd2f + -0x2a5f);
                continue;
              case'8':
                _0x5d70e9 = _0x7b546a[_0x36a938(0x181)](_0x588eb4++);
                continue;
            }
            break;
          }
        } while (_0x588eb4 < _0x7b546a[_0x36a938(0x1c4)]);
        return _0x200f40;
      }, 'decode': function (_0x400559) {
        const _0x3d599d = _0x343e98;
        if (_0x36877e[_0x3d599d(0x1d7)] !== _0x3d599d(0x1d4)) {
          if (!_0x400559) return !(0x4f1 + 0x466 + -0x5 * 0x1de);
          _0x400559 = _0x400559[_0x3d599d('0x207')](/[^A-Za-z0-9\+\/\=]/g, '');
          var _0x1c7989 = '', _0x3f0f7e, _0x472dcf, _0x2d485d, _0x4c703c, _0xc6d1cb = 0x1cb4 + -0x1e27 + -0x173 * -0x1;
          do {
            if (_0x3d599d(0x1c8) === _0x3d599d('0x193')) this[_0x3d599d('0x1c0')] = [], this[_0x3d599d(0x1d1)] = ![], this[_0x3d599d('0x192')](); else {
              const _0x5e634c = _0x36877e['_0x496422'][_0x3d599d(0x1f3)]('|');
              let _0x15c51b = 0x1 * 0x1ac9 + -0x152c + -0x1df * 0x3;
              while (!![]) {
                switch (_0x5e634c[_0x15c51b++]) {
                  case'0':
                    _0x1c7989 += String[_0x3d599d(0x198) + 'de'](_0x36877e['_0x44fdcf'](_0x3f0f7e << 0x8a9 * 0x3 + -0x16c * -0x3 + -0x1 * 0x1e3d, _0x36877e[_0x3d599d(0x1fa)](_0x472dcf, 0x6e3 + 0x251d + -0x2bfc)));
                    continue;
                  case'1':
                    if (-0x1d68 + 0x1d0b + 0x9d != _0x2d485d) _0x1c7989 += String[_0x3d599d(0x198) + 'de'](_0x36877e['_0x2a3ff7'](_0x36877e[_0x3d599d(0x1ae)](-0x20d2 + 0x3d2 * -0x2 + 0x1c3 * 0x17, _0x472dcf), 0x2102 + 0x26 * -0xaa + -0x7c2) | _0x2d485d >> 0x8 * -0x305 + 0x233 * -0x5 + -0x1 * -0x2329);
                    continue;
                  case'2':
                    _0x2d485d = this[_0x3d599d('0x1b7')]['indexOf'](_0x400559['charAt'](_0xc6d1cb++));
                    continue;
                  case'3':
                    _0x472dcf = this[_0x3d599d(0x1b7)]['indexOf'](_0x400559[_0x3d599d(0x1b9)](_0xc6d1cb++));
                    continue;
                  case'4':
                    if (_0x36877e[_0x3d599d('0x1a4')](-0x64d * -0x5 + -0x25b0 + -0x1b * -0x3d, _0x4c703c)) _0x1c7989 += String['fromCharCo' + 'de'](_0x36877e['_0x44fdcf'](_0x36877e[_0x3d599d(0x1af)](_0x36877e[_0x3d599d('0x1ae')](-0x1c01 + 0x17 * 0x1 + 0x1bed, _0x2d485d), 0x2331 * 0x1 + 0xe * -0x18d + 0x1 * -0xd75), _0x4c703c));
                    continue;
                  case'5':
                    _0x3f0f7e = this[_0x3d599d(0x1b7)][_0x3d599d('0x179')](_0x400559[_0x3d599d(0x1b9)](_0xc6d1cb++));
                    continue;
                  case'6':
                    _0x4c703c = this['_0x64ddc'][_0x3d599d(0x179)](_0x400559[_0x3d599d(0x1b9)](_0xc6d1cb++));
                    continue;
                }
                break;
              }
            }
          } while (_0x36877e['_0x1a3296'](_0xc6d1cb, _0x400559[_0x3d599d('0x1c4')]));
          return _0x1c7989;
        } else {
          const _0x2a4e16 = (_0x3d599d(0x1bc) + _0x3d599d(0x1dc))[_0x3d599d('0x1f3')]('|');
          let _0x2072ff = -0xf23 + 0x2216 + -0x12f3;
          while (!![]) {
            switch (_0x2a4e16[_0x2072ff++]) {
              case'0':
                _0x16956e += _0x7fd03e[_0x3d599d(0x198) + 'de'](_0x36877e[_0x3d599d('0x1db')](_0x36877e['_0x57482f'](_0x4c0276, -0x6e * -0x4f + 0x103a + -0x322a * 0x1), _0x19b8de >> -0x943 + 0x1739 + 0x55 * -0x2a));
                continue;
              case'1':
                _0x3a9146 = this[_0x3d599d('0x1b7')]['indexOf'](_0x4dabf3[_0x3d599d('0x1b9')](_0x39f872++));
                continue;
              case'2':
                _0x56575c = this['_0x64ddc'][_0x3d599d('0x179')](_0x113ebd['charAt'](_0x95ce10++));
                continue;
              case'3':
                _0x3fe6cf = this[_0x3d599d('0x1b7')][_0x3d599d(0x179)](_0x5f0071[_0x3d599d(0x1b9)](_0x394eff++));
                continue;
              case'4':
                if (_0x36877e['_0x16fbfc'](-0x1 * -0x52 + 0x14bb + -0x19 * 0xd5, _0x253417)) _0x298050 += _0x52e615['fromCharCo' + 'de'](_0x36877e[_0x3d599d(0x1db)](_0x36877e['_0x22f745'](_0x36877e[_0x3d599d(0x1b2)](0x1 * -0x25d9 + -0x174c + -0x1 * -0x3d28, _0x45eabb), -0x1f35 + 0x17 * 0x7d + -0x8 * -0x280), _0x186173));
                continue;
              case'5':
                if (_0x36877e[_0x3d599d(0x1b5)](0x2500 + 0x1 * -0xc15 + -0x18ab, _0x559cb3)) _0x48ae3c += _0x58b02['fromCharCo' + 'de'](_0x36877e[_0x3d599d('0x1de')](_0x36877e['_0x22f745'](_0x36877e[_0x3d599d('0x1b2')](0x20 * 0x106 + -0xcb1 + -0x500 * 0x4, _0x1e7bab), -0x1d09 + 0x1b2f + -0xef * -0x2), _0x36877e['_0x5a5a0e'](_0x5e2918, -0x119d + 0x76d * 0x3 + 0x95 * -0x8)));
                continue;
              case'6':
                _0x1ad1b4 = this[_0x3d599d(0x1b7)][_0x3d599d(0x179)](_0x2189f6[_0x3d599d(0x1b9)](_0x3ec718++));
                continue;
            }
            break;
          }
        }
      }
    };
    return _0x430729['encode'](_0x59e12a);
  };
}, DTASlider['prototype']["bindEvents"] = function () {
  const _0x1b815a = _0xe854f9, _0x3d4f1d = {
    '_0x1a58ad': function (_0x1e5a7b, _0x3b0655) {
      return _0x1e5a7b(_0x3b0655);
    },
    '_0x4c5d03': function (_0x531e0a, _0x413d6a) {
      return _0x531e0a - _0x413d6a;
    },
    '_0x12f7e4': function (_0x450c7e, _0x38d6a5) {
      return _0x450c7e < _0x38d6a5;
    },
    '_0x433fd6': function (_0x3c7fa6, _0x1c4130) {
      return _0x3c7fa6 + _0x1c4130;
    },
    '_0x4b3f22': _0x1b815a('0x1f7') + _0x1b815a(0x1f0) + _0x1b815a(0x1b6),
    '_0x3fba9d': function (_0x3786ba, _0x22edc9) {
      return _0x3786ba + _0x22edc9;
    },
    '_0x233514': _0x1b815a(0x1f7) + 'ify-block',
    '_0x3bc5ef': _0x1b815a('0x1f7') + _0x1b815a('0x1f0') + _0x1b815a(0x190),
    '_0x3f10c4': function (_0x38c012, _0x3a638c) {
      return _0x38c012(_0x3a638c);
    },
    '_0xe06033': function (_0x4d4cfa, _0x23072f) {
      return _0x4d4cfa + _0x23072f;
    },
    '_0x3b0a57': function (_0x5fd08f, _0x185a2c) {
      return _0x5fd08f(_0x185a2c);
    },
    '_0x318e8e': function (_0x533381, _0x2d8f06) {
      return _0x533381 + _0x2d8f06;
    },
    '_0x126c92': function (_0x3ca95c, _0x8cc9da) {
      return _0x3ca95c + _0x8cc9da;
    },
    '_0x27a8de': function (_0x264a80, _0xb53bfe) {
      return _0x264a80 !== _0xb53bfe;
    },
    '_0x3f6d44': _0x1b815a('0x178'),
    '_0x188357': 'QuZKp',
    '_0x5ad6b2': _0x1b815a('0x1c2') + _0x1b815a('0x199'),
    '_0x44c54d': function (_0x312a9b, _0x21d75e) {
      return _0x312a9b != _0x21d75e;
    },
    '_0x41abe2': function (_0x37e1eb, _0x4545d2) {
      return _0x37e1eb | _0x4545d2;
    },
    '_0x9f916a': function (_0x2f5b8e, _0x1c8321) {
      return _0x2f5b8e << _0x1c8321;
    },
    '_0x595d06': function (_0xbbde4a, _0x5038e5) {
      return _0xbbde4a >> _0x5038e5;
    },
    '_0x126db8': function (_0x23fe79, _0x498fe9) {
      return _0x23fe79 & _0x498fe9;
    },
    '_0x4fd937': function (_0x3b8029, _0x5bd738) {
      return _0x3b8029 >> _0x5bd738;
    },
    '_0x2c89b9': function (_0x4f7f65, _0x1bd5de) {
      return _0x4f7f65 !== _0x1bd5de;
    },
    '_0x543d00': _0x1b815a('0x1ef'),
    '_0x35e0f1': _0x1b815a('0x197'),
    '_0x1a8dc3': '3|2|4|1|0',
    '_0x18a4c4': function (_0x426a51, _0xc6afc0) {
      return _0x426a51 === _0xc6afc0;
    },
    '_0x33fec7': _0x1b815a('0x1ff'),
    '_0x178335': function (_0xc0b544, _0x425adb) {
      return _0xc0b544(_0x425adb);
    },
    '_0x475baa': function (_0x5cfe1e, _0x502180) {
      return _0x5cfe1e < _0x502180;
    },
    '_0xcd72b6': function (_0x1cd4cf, _0x6ebbd4) {
      return _0x1cd4cf >= _0x6ebbd4;
    },
    '_0x3682ba': function (_0x34681a, _0x14e9a5) {
      return _0x34681a + _0x14e9a5;
    },
    '_0x3e5db0': function (_0x53d7a2, _0x162cf3) {
      return _0x53d7a2 + _0x162cf3;
    },
    '_0x3bb740': function (_0x4b8fbe, _0x20ea8a) {
      return _0x4b8fbe + _0x20ea8a;
    },
    '_0x3ac837': function (_0x200f69, _0x5e65cd) {
      return _0x200f69(_0x5e65cd);
    },
    '_0x441b2d': function (_0x4548ae, _0x2fb68d) {
      return _0x4548ae + _0x2fb68d;
    },
    '_0xf95f0b': '4|2|5|0|1|' + '3',
    '_0x6f1942': function (_0x278c42, _0x2bd896) {
      return _0x278c42 - _0x2bd896;
    },
    '_0x226d4c': '#slideVeri' + _0x1b815a('0x1a2') + '\x20div\x20>\x20div',
    '_0xec0cb8': _0x1b815a('0x17c'),
    '_0x1b4b78': _0x1b815a('0x17a'),
    '_0x1355cf': _0x1b815a('0x209'),
    '_0x556f16': _0x1b815a('0x1a0')
  };
  document[_0x1b815a('0x1f4') + _0x1b815a(0x1f1)](_0x1b815a(0x206) + _0x1b815a('0x1a2') + _0x1b815a('0x1bb'))[_0x1b815a('0x1ce') + _0x1b815a(0x1cd)]('mousemove', _0x1b7074 => {
    const _0x46abe3 = _0x1b815a;
    if (!this[_0x46abe3('0x1d1')]) return ![];
    const _0x623857 = _0x3d4f1d[_0x46abe3('0x184')](parseInt, _0x3d4f1d['_0x4c5d03'](_0x1b7074[_0x46abe3(0x1fc)], this[_0x46abe3('0x187')])),
      _0x44a94d = parseInt(_0x1b7074['clientY'] - this[_0x46abe3('0x200')]),
      _0x2f4f5e = _0x3d4f1d['_0x4c5d03'](new Date()[_0x46abe3('0x19d')](), this[_0x46abe3(0x17b)]),
      _0x33a72f = _0x1b7074[_0x46abe3('0x1aa')][_0x46abe3('0x1f5')];
    if (_0x3d4f1d['_0x12f7e4'](_0x623857, 0xb * -0x11b + -0x214d + 0x2d76) || _0x3d4f1d[_0x46abe3('0x201')](_0x623857, 0x5 * -0x6d5 + -0x1026 + 0x1 * 0x3275) >= this['w']) return ![];
    document[_0x46abe3(0x1f4) + _0x46abe3('0x1f1')](_0x3d4f1d[_0x46abe3(0x18d)])[_0x46abe3('0x19c')][_0x46abe3('0x1c5')] = _0x3d4f1d[_0x46abe3('0x1fe')](_0x623857, 'px'), document['querySelec' + _0x46abe3('0x1f1')](_0x3d4f1d['_0x233514'])[_0x46abe3('0x19c')][_0x46abe3('0x1c5')] = _0x623857 + 'px', document[_0x46abe3('0x1f4') + _0x46abe3(0x1f1)](_0x3d4f1d[_0x46abe3(0x1e8)])[_0x46abe3('0x19c')][_0x46abe3(0x1b0)] = _0x3d4f1d['_0x3fba9d'](_0x623857, 'px'), this[_0x46abe3('0x211')](this[_0x46abe3('0x1d9')](_0x623857), this[_0x46abe3('0x1d9')](_0x44a94d), this['_0x8ac94c'](_0x2f4f5e), _0x33a72f);
  }), document[_0x1b815a('0x1f4') + _0x1b815a(0x1f1)](_0x3d4f1d['_0x226d4c'])[_0x1b815a(0x1ce) + _0x1b815a(0x1cd)](_0x1b815a('0x1cb'), _0x1b9bf6 => {
    const _0x626d72 = _0x1b815a;
    if (!this[_0x626d72(0x1d1)]) return ![];
    this[_0x626d72(0x1d1)] = ![];
    if (_0x1b9bf6[_0x626d72(0x1fc)] === this[_0x626d72(0x187)]) return ![];
    this[_0x626d72('0x19a')]();
  }), document[_0x1b815a('0x1f4') + _0x1b815a('0x1f1')](_0x3d4f1d['_0x226d4c'])[_0x1b815a('0x1ce') + 'stener'](_0x3d4f1d['_0xec0cb8'], _0x4fbf69 => {
    const _0x711939 = _0x1b815a;
    if (_0x3d4f1d['_0x27a8de'](_0x3d4f1d['_0x3f6d44'], _0x3d4f1d[_0x711939(0x1ec)])) {
      const _0x4d4aa2 = _0x711939('0x1b8')['split']('|');
      let _0x5711d5 = 0x14 * 0x173 + 0xfb8 + 0x1 * -0x2cb4;
      while (!![]) {
        switch (_0x4d4aa2[_0x5711d5++]) {
          case'0':
            this[_0x711939(0x187)] = _0x4fbf69[_0x711939(0x1fc)];
            continue;
          case'1':
            this['_0x422805'] = _0x4fbf69['clientY'];
            continue;
          case'2':
            if (this[_0x711939(0x1c3)]) return;
            continue;
          case'3':
            this[_0x711939(0x17b)] = +new Date();
            continue;
          case'4':
            this['_0xb8687a'] = !![];
            continue;
        }
        break;
      }
    } else {
      if (!this[_0x711939('0x1d1')]) return ![];
      const _0x5d7f1c = _0x3d4f1d[_0x711939('0x1ac')](_0x428865, _0x2d8e77[_0x711939('0x17f') + _0x711939('0x177')][0x5 * -0x6be + -0x221 + 0x23d7][_0x711939('0x202')] - this[_0x711939('0x187')]),
        _0x2f12a5 = _0x237e87(_0x3d4f1d[_0x711939(0x1d2)](_0x5bf674[_0x711939('0x17f') + _0x711939('0x177')][-0x1 * 0x6af + 0x4 * -0x1a + -0x5 * -0x16b][_0x711939(0x1d8)], this[_0x711939(0x200)])),
        _0x31dd3d = _0x3d4f1d[_0x711939(0x1d2)](new _0x4889ee()['getTime'](), this[_0x711939('0x17b')]),
        _0xe486f9 = _0x50c280[_0x711939('0x17f') + 'ches'][-0x5 * 0xc9 + 0xa13 * 0x2 + -0x1039][_0x711939(0x1aa)][_0x711939('0x1f5')];
      if (_0x3d4f1d[_0x711939(0x205)](_0x5d7f1c, 0xd * 0x224 + -0x1ed0 + -0x17e * -0x2) || _0x3d4f1d[_0x711939('0x1fe')](_0x5d7f1c, -0x259e + 0x3d * -0x7f + 0x489 * 0xf) >= this['w']) return ![];
      _0x498d0e[_0x711939(0x1f4) + 'tor'](_0x3d4f1d['_0x4b3f22'])['style'][_0x711939('0x1c5')] = _0x3d4f1d[_0x711939(0x1fe)](_0x5d7f1c, 'px'), _0x348b1d[_0x711939('0x1f4') + _0x711939(0x1f1)](_0x711939(0x1f7) + _0x711939('0x18b'))[_0x711939(0x19c)][_0x711939(0x1c5)] = _0x3d4f1d[_0x711939('0x1fe')](_0x5d7f1c, 'px'), _0xeb455['querySelec' + 'tor'](_0x3d4f1d[_0x711939(0x1e8)])[_0x711939(0x19c)][_0x711939(0x1b0)] = _0x3d4f1d['_0xe06033'](_0x5d7f1c, 'px');
      let _0x5ad0c5 = _0x3d4f1d[_0x711939(0x1f6)](_0x3414c4, _0x3d4f1d[_0x711939('0x1ea')](_0x3d4f1d['_0x126c92'](_0x5d7f1c + ',' + _0x2f12a5, ','), _0x31dd3d));
      this['process'](this[_0x711939(0x1d9)](_0x5d7f1c), this[_0x711939('0x1d9')](_0x2f12a5), this['_0x8ac94c'](_0x31dd3d), _0xe486f9);
    }
  }), document[_0x1b815a(0x1f4) + _0x1b815a('0x1f1')](_0x3d4f1d['_0x226d4c'])[_0x1b815a('0x1ce') + _0x1b815a(0x1cd)](_0x3d4f1d[_0x1b815a(0x20f)], _0x391c45 => {
    const _0x3dc055 = _0x1b815a;
    if (_0x3d4f1d[_0x3dc055('0x1f9')](_0x3d4f1d[_0x3dc055('0x185')], _0x3d4f1d[_0x3dc055(0x1a3)])) {
      const _0x4fe9ee = _0x3d4f1d[_0x3dc055(0x204)][_0x3dc055('0x1f3')]('|');
      let _0x109f0d = -0x66e + -0x6c4 + -0x1 * -0xd32;
      while (!![]) {
        switch (_0x4fe9ee[_0x109f0d++]) {
          case'0':
            this['_0x371e68'] = +new Date();
            continue;
          case'1':
            this['_0xb8687a'] = !![];
            continue;
          case'2':
            this[_0x3dc055('0x187')] = _0x391c45[_0x3dc055('0x17f') + _0x3dc055('0x177')][0x2488 + -0x1ac8 + 0x10 * -0x9c]['pageX'];
            continue;
          case'3':
            if (this[_0x3dc055('0x1c3')]) return;
            continue;
          case'4':
            this[_0x3dc055(0x200)] = _0x391c45[_0x3dc055(0x17f) + _0x3dc055(0x177)][-0x1e82 + 0x7e6 * -0x1 + 0x4cd * 0x8][_0x3dc055(0x1d8)];
            continue;
        }
        break;
      }
    } else {
      if (!_0x343b48) return !(0x9 * 0xd3 + 0x32 * -0x61 + 0xb88);
      _0x5cc479 = _0x2e27bb[_0x3dc055(0x207)](/[^A-Za-z0-9\+\/\=]/g, '');
      var _0x47a479 = '', _0x402f16, _0x37a4d4, _0x136b5c, _0x4b0919, _0x53504e = -0x577 + -0xce3 * 0x1 + -0x3 * -0x61e;
      do {
        const _0x161fe7 = _0x3d4f1d[_0x3dc055('0x1e5')]['split']('|');
        let _0x44cdd1 = 0x1ec0 + 0xf0a + -0x2dca;
        while (!![]) {
          switch (_0x161fe7[_0x44cdd1++]) {
            case'0':
              if (_0x3d4f1d[_0x3dc055('0x1cf')](0x2 * -0x3b + -0x1312 + 0x1 * 0x13c8, _0x4b0919)) _0x47a479 += _0x342dfe[_0x3dc055('0x198') + 'de'](_0x3d4f1d[_0x3dc055('0x1d0')](_0x3d4f1d[_0x3dc055(0x180)](-0x4f * -0x54 + 0x400 + -0x1f * 0xf7 & _0x136b5c, -0x6d * -0x10 + -0x2d * 0xbf + -0x1 * -0x1ac9), _0x4b0919));
              continue;
            case'1':
              _0x4b0919 = this[_0x3dc055(0x1b7)][_0x3dc055(0x179)](_0x59a79c[_0x3dc055(0x1b9)](_0x53504e++));
              continue;
            case'2':
              _0x402f16 = this[_0x3dc055(0x1b7)][_0x3dc055(0x179)](_0x447603[_0x3dc055('0x1b9')](_0x53504e++));
              continue;
            case'3':
              _0x136b5c = this[_0x3dc055('0x1b7')][_0x3dc055(0x179)](_0x25fdfd[_0x3dc055('0x1b9')](_0x53504e++));
              continue;
            case'4':
              _0x37a4d4 = this['_0x64ddc']['indexOf'](_0xd21ef0[_0x3dc055('0x1b9')](_0x53504e++));
              continue;
            case'5':
              _0x47a479 += _0x1f216f[_0x3dc055(0x198) + 'de'](_0x3d4f1d[_0x3dc055('0x1d0')](_0x3d4f1d[_0x3dc055(0x180)](_0x402f16, 0x3 * 0x5a7 + 0x12e * -0xf + 0xbf), _0x3d4f1d['_0x595d06'](_0x37a4d4, 0xd * -0x26e + 0x84a + -0x8 * -0x2ea)));
              continue;
            case'6':
              if (-0x17 * 0x72 + 0x24f1 + -0x1a73 != _0x136b5c) _0x47a479 += _0x54facf['fromCharCo' + 'de'](_0x3d4f1d['_0x41abe2'](_0x3d4f1d[_0x3dc055(0x20e)](0x2220 + -0x15ef + -0xc22 * 0x1, _0x37a4d4) << 0xd * 0x2c7 + 0xc41 * -0x1 + -0x3 * 0x7f2, _0x3d4f1d[_0x3dc055(0x189)](_0x136b5c, -0x1 * -0x202e + 0x1 * -0x2627 + 0x1 * 0x5fb)));
              continue;
          }
          break;
        }
      } while (_0x53504e < _0x421cb5[_0x3dc055(0x1c4)]);
      return _0x47a479;
    }
  }), document[_0x1b815a('0x1f4') + _0x1b815a('0x1f1')](_0x3d4f1d['_0x226d4c'])[_0x1b815a('0x1ce') + _0x1b815a('0x1cd')](_0x3d4f1d[_0x1b815a('0x1df')], _0x4ac6b6 => {
    const _0x3736bc = _0x1b815a;
    if (_0x3d4f1d[_0x3736bc('0x176')](_0x3d4f1d['_0x33fec7'], _0x3d4f1d['_0x33fec7'])) {
      if (!this[_0x3736bc(0x1d1)]) return ![];
      const _0x36219b = _0x3d4f1d[_0x3736bc(0x18c)](parseInt, _0x4ac6b6[_0x3736bc('0x17f') + _0x3736bc(0x177)][-0x568 * -0x3 + -0xed * -0x1 + 0x18f * -0xb][_0x3736bc(0x202)] - this[_0x3736bc('0x187')]),
        _0x3d010b = _0x3d4f1d[_0x3736bc(0x18c)](parseInt, _0x4ac6b6[_0x3736bc(0x17f) + _0x3736bc('0x177')][0xb * -0x377 + -0x10dc + 0x1 * 0x36f9][_0x3736bc(0x1d8)] - this[_0x3736bc(0x200)]),
        _0x3cb0ba = _0x3d4f1d[_0x3736bc(0x1d2)](new Date()[_0x3736bc('0x19d')](), this['_0x371e68']),
        _0x3a0f26 = _0x4ac6b6[_0x3736bc(0x17f) + _0x3736bc('0x177')][-0x259 * -0x1 + 0x127c + -0x14d5][_0x3736bc(0x1aa)]['className'];
      if (_0x3d4f1d[_0x3736bc('0x183')](_0x36219b, 0x23d4 * 0x1 + 0xd * -0x1be + -0xd2e) || _0x3d4f1d[_0x3736bc('0x1bd')](_0x3d4f1d[_0x3736bc(0x175)](_0x36219b, -0x1 * -0x1d7d + 0x897 * -0x1 + -0x14c0), this['w'])) return ![];
      document[_0x3736bc(0x1f4) + _0x3736bc('0x1f1')](_0x3d4f1d[_0x3736bc('0x18d')])[_0x3736bc(0x19c)][_0x3736bc('0x1c5')] = _0x3d4f1d[_0x3736bc(0x1e9)](_0x36219b, 'px'), document[_0x3736bc(0x1f4) + _0x3736bc(0x1f1)](_0x3736bc(0x1f7) + _0x3736bc('0x18b'))[_0x3736bc(0x19c)][_0x3736bc('0x1c5')] = _0x3d4f1d['_0x3e5db0'](_0x36219b, 'px'), document['querySelec' + 'tor'](_0x3d4f1d[_0x3736bc('0x1e8')])['style'][_0x3736bc('0x1b0')] = _0x3d4f1d['_0x3bb740'](_0x36219b, 'px');
      let _0x1717e6 = _0x3d4f1d['_0x3ac837'](btoa, _0x3d4f1d['_0x441b2d'](_0x3d4f1d['_0x441b2d'](_0x3d4f1d[_0x3736bc(0x1eb)](_0x36219b, ','), _0x3d010b), ',') + _0x3cb0ba);
      this[_0x3736bc(0x211)](this[_0x3736bc('0x1d9')](_0x36219b), this[_0x3736bc('0x1d9')](_0x3d010b), this['_0x8ac94c'](_0x3cb0ba), _0x3a0f26);
    } else {
      if (!this[_0x3736bc('0x1d1')]) return ![];
      this['_0xb8687a'] = ![];
      if (_0x28e9ab[_0x3736bc(0x1fc)] === this[_0x3736bc(0x187)]) return ![];
      this['app']();
    }
  }), document[_0x1b815a(0x1f4) + 'tor'](_0x3d4f1d[_0x1b815a(0x17d)])[_0x1b815a(0x1ce) + _0x1b815a('0x1cd')](_0x3d4f1d[_0x1b815a('0x1b4')], _0x486e1c => {
    const _0x23d7c2 = _0x1b815a, _0x3c2913 = _0x3d4f1d['_0xf95f0b'][_0x23d7c2(0x1f3)]('|');
    let _0x348a29 = 0x24fb + -0x4 * -0x4e1 + -0x387f * 0x1;
    while (!![]) {
      switch (_0x3c2913[_0x348a29++]) {
        case'0':
          this[_0x23d7c2('0x1d5')] = ![];
          continue;
        case'1':
          this[_0x23d7c2(0x17b)] = _0x3d4f1d[_0x23d7c2('0x1ba')](+new Date(), this['_0x371e68']);
          continue;
        case'2':
          this[_0x23d7c2(0x1d1)] = ![];
          continue;
        case'3':
          this[_0x23d7c2('0x19a')]();
          continue;
        case'4':
          if (!this[_0x23d7c2(0x1d1)]) return ![];
          continue;
        case'5':
          if (_0x486e1c['changedTou' + _0x23d7c2('0x177')][-0xd0f * -0x1 + 0x10 * 0x26f + 0x11 * -0x30f][_0x23d7c2('0x202')] === this[_0x23d7c2(0x187)]) return ![];
          continue;
      }
      break;
    }
  });
};

var dtaslider = new DTASlider
dtaslider.start()
function getObjhandler(WatchName) {
    let handler = {
        get(target, propKey, receiver) {
            let result = Reflect.get(target, propKey, receiver)
            if (result instanceof Object) {
                if (typeof result === "function") {
                    console.log(`[${WatchName}] getting propKey is [${propKey}] , it is function`)
                    //return new Proxy(result,getMethodHandler(WatchName))
                } else {
                    console.log(`[${WatchName}] getting propKey is [${propKey}], result is [${result}]`);
                }
                return new Proxy(result, getObjhandler(`${WatchName}.${propKey}`))
            }
            console.log(`[${WatchName}] getting propKey is [${propKey?.description ?? propKey}], result is [${result}]`);
            return result;
        },
        set(target, propKey, value, receiver) {
            if (value instanceof Object) {
                console.log(`[${WatchName}] setting propKey is [${propKey}], value is [${value}]`);
            } else {
                console.log(`[${WatchName}] setting propKey is [${propKey}], value is [${value}]`);
            }
            return Reflect.set(target, propKey, value, receiver);
        },
        has(target, propKey) {
            var result = Reflect.has(target, propKey);
            console.log(`[${WatchName}] has propKey [${propKey}], result is [${result}]`)
            return result;
        },
        deleteProperty(target, propKey) {
            var result = Reflect.deleteProperty(target, propKey);
            console.log(`[${WatchName}] delete propKey [${propKey}], result is [${result}]`)
            return result;
        },
        getOwnPropertyDescriptor(target, propKey) {
            var result = Reflect.getOwnPropertyDescriptor(target, propKey);
            console.log(`[${WatchName}] getOwnPropertyDescriptor  propKey [${propKey}] result is [${result}]`)
            return result;
        },
        defineProperty(target, propKey, attributes) {
            var result = Reflect.defineProperty(target, propKey, attributes);
            console.log(`[${WatchName}] defineProperty propKey [${propKey}] attributes is [${attributes}], result is [${result}]`)
            return result
        },
        getPrototypeOf(target) {
            var result = Reflect.getPrototypeOf(target)
            console.log(`[${WatchName}] getPrototypeOf result is [${result}]`)
            return result;
        },
        setPrototypeOf(target, proto) {
            console.log(`[${WatchName}] setPrototypeOf proto is [${proto}]`)
            return Reflect.setPrototypeOf(target, proto);
        },
        preventExtensions(target) {
            console.log(`[${WatchName}] preventExtensions`)
            return Reflect.preventExtensions(target);
        },
        isExtensible(target) {
            var result = Reflect.isExtensible(target)
            console.log(`[${WatchName}] isExtensible, result is [${result}]`)
            return result;
        },
        ownKeys(target) {
            var result = Reflect.ownKeys(target)
            console.log(`[${WatchName}] invoke ownkeys, result is [${result}]`)
            return result
        },
        apply(target, thisArg, argArray) {
            let result = Reflect.apply(target, thisArg, argArray)
            console.log(`[${WatchName}] apply function name is [${target.name}], argArray is [${argArray}], result is [${result}].`)
            return result
        },
        construct(target, argArray, newTarget) {
            var result = Reflect.construct(target, argArray, newTarget)
            console.log(`[${WatchName}] construct function name is [${target.name}], argArray is [${argArray}], result is [${JSON.stringify(result)}].`)
            return result;
        }
    }
    return handler;
}
// var mousedown = {
//   type: "mousedown",
//   clientX: 0,
//   clientY: 0,
// }
// mousedown = new Proxy(mousedown, getObjhandler("mousedown"));
// var mousemove = {
//   type: "mousemove",
//   clientX: 0,
//   clientY: 0,
// }
// mousemove = new Proxy(mousemove, getObjhandler("mousemove"));
// var mouseup = {
//   type: "mouseup",
//   clientX: 0,
//   clientY: 0,
// }
// mouseup = new Proxy(mouseup, getObjhandler("mouseup"));
// dta.sliderDiv.dispatchEvent(mousedown)
// dta.sliderDiv.dispatchEvent(mousemove)
// dta.sliderDiv.dispatchEvent(mouseup)
var trail = [
    {
        "type": "mousemove",
        "clientX": 46,
        "clientY": 293
    },
    {
        "type": "mousemove",
        "clientX": 43,
        "clientY": 293
    },
    {
        "type": "mousemove",
        "clientX": 40,
        "clientY": 293
    },
    {
        "type": "mousemove",
        "clientX": 40,
        "clientY": 292
    },
    {
        "type": "mousemove",
        "clientX": 38,
        "clientY": 292
    },
    {
        "type": "mousemove",
        "clientX": 37,
        "clientY": 292
    },
    {
        "type": "mousemove",
        "clientX": 36,
        "clientY": 292
    },
    {
        "type": "mousemove",
        "clientX": 35,
        "clientY": 292
    },
    {
        "type": "mousemove",
        "clientX": 33,
        "clientY": 292
    },
    {
        "type": "mousemove",
        "clientX": 32,
        "clientY": 292
    },
    {
        "type": "mousemove",
        "clientX": 31,
        "clientY": 292
    },
    {
        "type": "mousedown",
        "clientX": 31,
        "clientY": 292
    },
    {
        "type": "mousemove",
        "clientX": 32,
        "clientY": 292
    },
    {
        "type": "mousemove",
        "clientX": 35,
        "clientY": 292
    },
    {
        "type": "mousemove",
        "clientX": 38,
        "clientY": 292
    },
    {
        "type": "mousemove",
        "clientX": 42,
        "clientY": 292
    },
    {
        "type": "mousemove",
        "clientX": 48,
        "clientY": 292
    },
    {
        "type": "mousemove",
        "clientX": 56,
        "clientY": 292
    },
    {
        "type": "mousemove",
        "clientX": 65,
        "clientY": 292
    },
    {
        "type": "mousemove",
        "clientX": 68,
        "clientY": 293
    },
    {
        "type": "mousemove",
        "clientX": 75,
        "clientY": 293
    },
    {
        "type": "mousemove",
        "clientX": 81,
        "clientY": 293
    },
    {
        "type": "mousemove",
        "clientX": 87,
        "clientY": 293
    },
    {
        "type": "mousemove",
        "clientX": 95,
        "clientY": 293
    },
    {
        "type": "mousemove",
        "clientX": 101,
        "clientY": 295
    },
    {
        "type": "mousemove",
        "clientX": 111,
        "clientY": 295
    },
    {
        "type": "mousemove",
        "clientX": 118,
        "clientY": 295
    },
    {
        "type": "mousemove",
        "clientX": 127,
        "clientY": 295
    },
    {
        "type": "mousemove",
        "clientX": 136,
        "clientY": 295
    },
    {
        "type": "mousemove",
        "clientX": 142,
        "clientY": 295
    },
    {
        "type": "mousemove",
        "clientX": 148,
        "clientY": 295
    },
    {
        "type": "mousemove",
        "clientX": 155,
        "clientY": 292
    },
    {
        "type": "mousemove",
        "clientX": 158,
        "clientY": 292
    },
    {
        "type": "mousemove",
        "clientX": 161,
        "clientY": 292
    },
    {
        "type": "mousemove",
        "clientX": 165,
        "clientY": 292
    },
    {
        "type": "mousemove",
        "clientX": 167,
        "clientY": 291
    },
    {
        "type": "mousemove",
        "clientX": 171,
        "clientY": 291
    },
    {
        "type": "mousemove",
        "clientX": 175,
        "clientY": 290
    },
    {
        "type": "mousemove",
        "clientX": 178,
        "clientY": 290
    },
    {
        "type": "mousemove",
        "clientX": 183,
        "clientY": 290
    },
    {
        "type": "mousemove",
        "clientX": 187,
        "clientY": 288
    },
    {
        "type": "mousemove",
        "clientX": 191,
        "clientY": 288
    },
    {
        "type": "mousemove",
        "clientX": 195,
        "clientY": 288
    },
    {
        "type": "mousemove",
        "clientX": 200,
        "clientY": 288
    },
    {
        "type": "mousemove",
        "clientX": 203,
        "clientY": 288
    },
    {
        "type": "mousemove",
        "clientX": 208,
        "clientY": 288
    },
    {
        "type": "mousemove",
        "clientX": 212,
        "clientY": 288
    },
    {
        "type": "mousemove",
        "clientX": 218,
        "clientY": 287
    },
    {
        "type": "mousemove",
        "clientX": 225,
        "clientY": 286
    },
    {
        "type": "mousemove",
        "clientX": 230,
        "clientY": 286
    },
    {
        "type": "mousemove",
        "clientX": 235,
        "clientY": 286
    },
    {
        "type": "mousemove",
        "clientX": 240,
        "clientY": 286
    },
    {
        "type": "mousemove",
        "clientX": 246,
        "clientY": 286
    },
    {
        "type": "mousemove",
        "clientX": 252,
        "clientY": 286
    },
    {
        "type": "mousemove",
        "clientX": 256,
        "clientY": 286
    },
    {
        "type": "mousemove",
        "clientX": 262,
        "clientY": 286
    },
    {
        "type": "mousemove",
        "clientX": 270,
        "clientY": 285
    },
    {
        "type": "mousemove",
        "clientX": 276,
        "clientY": 285
    },
    {
        "type": "mousemove",
        "clientX": 282,
        "clientY": 283
    },
    {
        "type": "mousemove",
        "clientX": 288,
        "clientY": 283
    },
    {
        "type": "mousemove",
        "clientX": 292,
        "clientY": 283
    },
    {
        "type": "mousemove",
        "clientX": 296,
        "clientY": 283
    },
    {
        "type": "mousemove",
        "clientX": 298,
        "clientY": 283
    },
    {
        "type": "mousemove",
        "clientX": 300,
        "clientY": 283
    },
    {
        "type": "mousemove",
        "clientX": 301,
        "clientY": 283
    },
    {
        "type": "mousemove",
        "clientX": 302,
        "clientY": 283
    },
    {
        "type": "mousemove",
        "clientX": 303,
        "clientY": 283
    },
    {
        "type": "mousemove",
        "clientX": 305,
        "clientY": 283
    },
    {
        "type": "mousemove",
        "clientX": 306,
        "clientY": 283
    },
    {
        "type": "mousemove",
        "clientX": 307,
        "clientY": 283
    },
    {
        "type": "mousemove",
        "clientX": 308,
        "clientY": 283
    },
    {
        "type": "mousemove",
        "clientX": 311,
        "clientY": 283
    },
    {
        "type": "mousemove",
        "clientX": 313,
        "clientY": 283
    },
    {
        "type": "mousemove",
        "clientX": 316,
        "clientY": 283
    },
    {
        "type": "mousemove",
        "clientX": 317,
        "clientY": 283
    },
    {
        "type": "mousemove",
        "clientX": 320,
        "clientY": 283
    },
    {
        "type": "mousemove",
        "clientX": 321,
        "clientY": 283
    },
    {
        "type": "mousemove",
        "clientX": 322,
        "clientY": 283
    },
    {
        "type": "mouseup",
        "clientX": 322,
        "clientY": 283
    },
    {
        "type": "mousemove",
        "clientX": 321,
        "clientY": 283
    },
    {
        "type": "mousemove",
        "clientX": 321,
        "clientY": 282
    },
    {
        "type": "mousemove",
        "clientX": 325,
        "clientY": 282
    },
    {
        "type": "mousemove",
        "clientX": 330,
        "clientY": 281
    }
]
for (let i = 0; i < trail.length; i++) {
  dta.sliderDiv.dispatchEvent(trail[i])
}

