package com.dta.first;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button btn_change;
    private TextView tv_helloword;
    private EditText edt_input;
    private CheckBox cb_read;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_change = findViewById(R.id.btn_change);
        tv_helloword = findViewById(R.id.tv_hello);
        edt_input = findViewById(R.id.edt_input);
        cb_read = findViewById(R.id.cb_read);
        btn_change.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                String inputText = edt_input.getText().toString();
                if (inputText.equals("")){
                    Toast.makeText(MainActivity.this,"please input something!",Toast.LENGTH_LONG).show();
                    return;
                }
                /*tv_helloword.setText(inputText);
                tv_helloword.setBackgroundColor(getColor(R.color.yellow));*/
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                AlertDialog alertDialog = builder.setMessage(inputText)
                        .setTitle("Title")
                        .setCancelable(true)
                        .setNegativeButton("cancle", null).create();
                alertDialog.show();

            }
        });

        cb_read.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                btn_change.setEnabled(isChecked);
            }
        });
    }
}