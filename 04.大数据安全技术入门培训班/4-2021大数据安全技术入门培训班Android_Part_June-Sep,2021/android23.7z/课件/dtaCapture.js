function main(){
    Java.perform(function(){
        //Http request
        Java.use("java.net.SocketOutputStream").socketWrite0.implementation = function(fd,bytes,off,len){
            printAddress(this.socket, true)
            hexdump(bytes,off,len)
            showStacks()
            this.socketWrite0(fd,bytes,off,len)
        }
        //Http response
        Java.use("java.net.SocketInputStream").socketRead0.implementation = function(fd,bytes,off,len,timeout){
            printAddress(this.socket, false)
            hexdump(bytes,off,len)
            showStacks()
            return this.socketRead0(fd,bytes,off,len,timeout)
        }

        //Https request
        Java.use("com.android.org.conscrypt.NativeCrypto").SSL_write.implementation = function(sslNativePointer,fd,shc,bytes,off,len,timeout){
            printHttpsAddress(fd)
            hexdump(bytes,off,len)
            showStacks()
            return this.SSL_write(sslNativePointer,fd,shc,bytes,off,len,timeout)
        }
        //Https response
        Java.use("com.android.org.conscrypt.NativeCrypto").SSL_read.implementation = function(sslNativePointer,fd,shc,bytes,off,len,timeout){
            printHttpsAddress(fd)
            hexdump(bytes,off,len)
            showStacks()
            return this.SSL_read(sslNativePointer,fd,shc,bytes,off,len,timeout)
        }

        function printHttpsAddress(fd, isSend){
            var local = Socket.localAddress(fd.getInt$())
            var peer = Socket.peerAddress(fd.getInt$())
            if(isSend){
                console.log(local.ip+":"+local.port +"====>"+ peer.ip+":"+peer.port)
            }else{
                console.log(peer.ip+":"+peer.port +"====>"+ local.ip+":"+local.port)
            }
        }

        function printAddress(socket, isSend){
            var localAddress = socket.value.getLocalAddress().toString()
            var remoteAddress = socket.value.getRemoteSocketAddress().toString()
            if(isSend){
                console.log(localAddress +"====>"+ remoteAddress)
            }else{
                console.log(remoteAddress +"====>"+ localAddress)
            }
        }

        function hexdump(bytearry,offset,length){
            var HexDump = Java.use("com.android.internal.util.HexDump")
            console.log(HexDump.dumpHexString(bytearry,offset,length))
        }
        
        function showStacks() {
            console.log(Java.use("android.util.Log").getStackTraceString(Java.use("java.lang.Exception").$new()));
        }
    })
}
setImmediate(main)