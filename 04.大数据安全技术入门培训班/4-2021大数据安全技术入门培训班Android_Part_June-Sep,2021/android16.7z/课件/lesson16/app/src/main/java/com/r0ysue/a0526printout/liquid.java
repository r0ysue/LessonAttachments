package com.r0ysue.a0526printout;

public interface liquid {
    public String flow();
}
