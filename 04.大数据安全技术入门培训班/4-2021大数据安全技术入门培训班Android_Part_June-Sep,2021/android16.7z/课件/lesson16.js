function main(){
    Java.perform(function (){
        // Java.use("java.lang.Character").toString.overload('char').implementation = function(x){
        //     console.log("Character.toString arg ==> ",x)
        //     var result = this.toString(x)
        //     console.log("Character.toString.Result ==> ",result)
        //     return result
        // }
        // new Gson().toJson(Object)
        // Java.openClassFile("/data/local/tmp/r0gson.dex").load()
        // var GsonClass = Java.use("com.r0ysue.gson.Gson")
        // Java.use("java.util.Arrays").toString.overload('[C').implementation = function(charArray){
        //     console.log("Arrays.toString arg ==> ", GsonClass.$new().toJson(charArray))
        //     //var modifyCharArray = ['R','0','Y','S','U']
        //     const modifyCharArray = Java.array('char', ['R','0','Y','S','U']);
        //     var result = this.toString(modifyCharArray)
        //     console.log("Arrays.toString.Result ==> ",result)
        //     return result
        // }

        // var WaterClass = Java.use("com.r0ysue.a0526printout.Water")
        // var WaterHandle = WaterClass.$new()
        // var Juice = WaterHandle.getInstance()
        // Juice = Java.cast(Juice,Java.use("com.r0ysue.a0526printout.Juice"))
        // Juice.fillEnergy()

        // var LiquidClass = Java.use("com.r0ysue.a0526printout.liquid")
        // var BeerClass = Java.registerClass({
        //     name:"com.r0ysue.a0526printout.Beer",
        //     implements: [LiquidClass],
        //     methods: {
        //         flow: function(){
        //             console.log("The beer's flow is Called!")
        //             return "";
        //         },
        //         add: {
        //             returnType: 'int',
        //             argumentTypes: ['int', 'int'],
        //             implementation(a, b) {
        //               return a+b
        //             }
        //         }
        //     }

        // })
        // console.log("The beer's add result ==> ",BeerClass.$new().add(1,3))

        // var Signal = Java.use("com.r0ysue.a0526printout.Signal")
        // var TrafficLightClass = Java.use("com.r0ysue.a0526printout.TrafficLight")
        // var TrafficLightHandle = TrafficLightClass.$new()
        // TrafficLightHandle.color.value = Signal.YELLOW.value
        // TrafficLightHandle.main()


    })
}
setImmediate(main)