package com.dta.demo13;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.HashMap;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText edt_username,edt_password;
    private Button btn_login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initView();
    }

    private void initView() {
        edt_username = findViewById(R.id.edt_username);
        edt_password = findViewById(R.id.edt_password);
        btn_login = findViewById(R.id.btn_login);
        btn_login.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_login:
                String username = edt_username.getText().toString();
                String password = edt_password.getText().toString();
                String body = "{\"verifyValue\":\""+password+"\",\"openInvite\":\"\",\"phoneNumber\":\""+username+"\",\"verifyMode\":\"2\",\"openChannel\":\"\"}";

                HashMap<String,String> headers = new HashMap<>();
                headers.put("Content-Type","text/plain; charset=utf-8");

                OkHttpUtil.post("http://uc.pairui1.com:8668//auth/login", headers, new String(AESUtils.encrypt(body,"f87210e0ed3079d8")), new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        //Toast.makeText(MainActivity.this,"Error",Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                        //Toast.makeText(MainActivity.this,response.body().string(),Toast.LENGTH_LONG).show();
                        Log.i("DTA===>",response.body().string());
                    }
                });
                break;
            default:

        }
    }
}