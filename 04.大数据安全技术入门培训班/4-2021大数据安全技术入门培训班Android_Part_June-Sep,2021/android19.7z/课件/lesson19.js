function main(){
    
    Java.perform(function(){
        // Frist
        // Java.use("com.dta.test.frida.activity.FirstActivity").check.implementation = function(z){
        //     z = true
        //     this.check(z)
        // }

        //Second
        // Java.use("com.dta.test.frida.activity.SecondActivity").check.implementation = function(){
        //     return true
        // }
        
        //Third
        // Java.choose("com.dta.test.frida.activity.ThirdActivity",{
        //     onMatch: function(ins){
        //         console.log(ins)
        //         ins.unknown.value = Java.use("com.dta.test.frida.base.Level").Fourth.value
        //     },onComplete: function(){
        //         console.log("Search Completed!")
        //     }
        // })


        // var Level = Java.use("com.dta.test.frida.base.Level")
        // Level.createLevel.implementation = function(i){
        //     return this.createLevel(4)
        // }

        //Fourth
        // Java.choose("com.dta.test.frida.activity.FourthActivity",{
        //     onMatch: function(ins){
        //         console.log(ins)
        //         ins.next()
        //     },onComplete: function(){
        //         console.log("Search Completed!")
        //     }
        // })

        //Fifth
        // var strarr = Java.array("java.lang.String",["a","b","b","b","b"])
        // Java.use("com.dta.test.frida.activity.FifthActivity").check.implementation = function(arr){
        //     arr = strarr
        //     this.check(arr)
        // }

        //Sixth
        // var RegisterClass = Java.registerClass({
        //     name: "com.dta.test.frida.activity.RegisterClass",
        //     methods: {
        //         next: {
        //             returnType: "boolean",
        //             argumentTypes:[],
        //             implementation: function(){
        //                 return true
        //             }
        //         }
        //     }
        // })
        // var targetClassLoader = RegisterClass.class.getClassLoader()
        // Java.enumerateClassLoaders({
        //     onMatch: function(loader){
        //         try{
        //             if(loader.findClass("com.dta.test.frida.activity.SixthActivity")){
        //                  // PathClassLoader
        //                  var PathClassLoader = loader
        //                  var BootClassLoader = PathClassLoader.parent.value

        //                  PathClassLoader.parent.value = targetClassLoader
        //                  targetClassLoader.parent.value = BootClassLoader
        //             }
                    
        //         }catch(e){

        //         }
                
        //     },onComplete: function(){
        //         console.log("Completed!")
        //     }
        // })

        //console.log(RegisterClass.$new().next())


        //Seven
        Java.enumerateClassLoaders({
            onMatch: function(loader){
                try{
                    if(loader.findClass("com.dta.frida.MyCheck")){
                        console.log("Found!")
                        Java.classFactory.loader = loader
                    }
                }catch(e){
                    
                }
            },onComplete: function(){
                console.log("Completed!")
            }
        })

        Java.use("com.dta.frida.MyCheck").check.implementation = function(){
            return true
        }
    })
}

setImmediate(main)