# 加壳基础原理-Android类加载器与双亲委派机制
> Fart脱壳王系列教程第一节课总结
## `Fart`脱壳王介绍
`Fart`在2019年开源过一个版本，想必大家对`Fart`或多或少有一些了解，一个强大自动化的脱壳工具。但是现在有很多加固的厂商已经对`Fart`的特征进行了检测，所以无法直接使用老版本的`Fart`。<font color='red'>所以Fart脱壳王登场，没错，Fart脱壳王呢就是Fart基于Android 10打造的增强版本，去掉了一些原有的Fart的特征，运行更加稳定！</font>
## 脱壳的重要性 Why脱壳
- 目前还有不加壳的APP吗？
- 想了解APP的架构，加壳了怎么办？
- 参加CTF挑战赛，不会`Android逆向`能行吗？
- 恶意APP怎么逆向分析？
- 公司开发的APP安全吗？有没有风险？
- 某移动互联网公司SRC奖金挺高啊，挖掘漏洞？
可以说，当前想要完成对一个app的逆向分析，脱壳是第一步！

 ## How to 识别壳
 我们可以使用常见的反编译工具`jdax`、`gda`、`jeb`等等
 - 查看dex的个数，只有一个dex的中等app大概率是加壳的
 - 把apk拖到常见的反编译工具里面去，像gda自带某些壳特征检测，会直接提示你app加了什么壳，也会直接告诉你：If you wanna  analyze the original APK，unpack it first！当然有的时候会误报，需要结合实际情况进行分析。
 - 如果能看到AndroidMenifest里面声明的相关组件信息，那么它大概率没有加壳，当然也不敢下定论，也有可能是抽取类的壳
 - 那如果直接看不到组件相关的类，那肯定就是加壳的app了
 - 如果你分析的样本足够多了，那么看到入口类你就可以知道它是哪家的壳。或者根据so的名字，不同厂商的so名字也不同，一见如故
## How to 脱壳
 首先，需要对Android平台APK的开发有所了解，比如何为四大组件？APP的运行流程，从点击Launcher图标到进入APP世界，进入APP世界先运行的那个方法等等。只有懂得正向开发，才能知道如何逆向分析。其次不知防，焉攻防？攻击和防御往往是一体的，只有先知道如何防守，我们才能懂得如何进攻！因此，我们要先学习Android加壳的原理，了解加固厂商是怎么对Android APP进行加壳的，为什么加了壳的应用还能正常运行，不干扰正常的执行逻辑，这样我们才能知道它们为什么这样做，进而思考怎么脱，为什么这样脱，甚至是定制自己的脱壳机，于是 Fart诞生了。

## APP加壳的根本原理
 加壳的目的就是为了保护APP原有的代码逻辑不轻易的被逆向人员看到。Android平台主流的APP代码绝大多是是由Java（Kotlin）进行编写以及c/c++甚至是汇编组成，Java代码被打包成dex文件，c/c++代码或汇编则编译生成so文件，对于加固厂商来说，他要保护的就是这两类文件。对于大部分的代码逻辑都是用Java来编写的，保存在dex文件中，所以dex文件就是一个app的关键，也是需要保护的重点，接下来的课程便主要是围绕dex文件的攻防展开。

## DEX文件保护技术的发展
dex文件保护技术的发展就是对dex文件保护粒度不断缩小的过程
 - dex整体加固保护
 - 函数粒度保护
 - smali指令粒度保护
dex整体加固的方案一直存在，也是其他加固方式的基础，因为整体加固的在内存中是比较完整的，如果从内存中将dex dump下来，那得到的其实就是未加固的dex，所以有了第二代函数粒度的保护，将一些关键的函数抽取出来，在运行的时候动态的将字节码指令填充回去，即使dex被整体dump下来，它的函数体也是被抽取掉的，来达到关键函数的保护作用，这个也是课程后面的内容。那么Fart呢也就是对抗这种被抽取壳保护的APP，我们怎么去彻底的还原每一个被保护的函数。而函数粒度的保护依然是需要art解释器解释执行的，依然可以按照函数粒度进行脱壳的，所以出现了后面粒度更细的保护-smali指令粒度的保护，这种保护就出现了两种保护的方案，一个呢就是dexvmp的保护，它自定义了解释器，可以让代码在自己的解释器中解释执行，这一部分内容在我们后面vmp课程进行讲解。另外一种方案就是dex2c，也是对smali指令粒度的保护。下面我们沿着这条发展路线，开始学习Android加壳保护的对抗

## DEX整体加固保护技术
- 分类：针对dex整体加固保护的主要技术可以大致分为两类：dex文件加载和dex内存加载。不管是哪种技术实现，其根本的原理都是dex动态加载的技术。
- 动态加载与双亲委派：开始进入第一节课的主要内容，学习了动态加载与双亲委派对以后进行编写HOOK代码的时候有非常大的帮助，有的同学可能遇到过ClassNotFoundException异常，它的原因呢就是咱们同学找错了类加载器ClassLoader

## 类加载器ClassLoader
### JVM类加载器
- JVM的类加载器包括三种：
- - Bootstrap ClassLoader（引导类加载器）：C/C++代码实现的加载器，用于加载指定的JDK核心的类库，比如java.lang.*、java.util.*等系统类。Java虚拟机的启动就是通过Bootstrap，该ClassLoader在java里面无法获取，只负责加载/lib下的类。

- - Extensions ClassLoader（拓展类加载器）：Java中的实现类为ExtClassLoader，提供了除了系统类之外的功能，可以在java里面获取，负责加载/lib/ext下的类。

- - Application ClassLoader（应用程序类加载器）：Java中的实现类为AppClassLoader，是与我们接触最多的类加载器，开发人员写的代码默认就是由它来加载，ClassLoader.getSystemClassLoader返回的就是它。
- - 自定义类加载器，只需要通过继承java.lang.ClassLoader类的方式来实现自己的类加载器即可。

![ClassLoader继承关系](https://mmbiz.qlogo.cn/mmbiz_png/7ePucpwVj77wlk95OAowVja3KfRzerfdnpx57pWLhoB6z5ZF6bZJrvQozeaCQNb2047ZnBiaaiauTTeCC1F2yLsg/0?wx_fmt=png "ClassLoader")

> 图中我们几种ClassLoader的继承关系，其中红色箭头所描述的就是双亲委派机制。当我们自定义类加载器想要加载一个类时，它首先不会自己想着去加载这个类，而是要先向上询问Application类加载器，你能帮我加载这个类吗？Application类加载器说，我上面还有你爷爷类加载器，就这样，直到找到Bootstrap类加载器，如果Bootstrap类加载器还没有加载过此类，那么就会反向让自己的子类去想办法处理加载。如果上层的类加载器能够加载该类，就直接加载成功了。简单点说就是每个儿子都不愿意干活，每次有活就它的父亲去干，知道父亲说这件事我干不了，让儿子想办法去完成，这个就是双亲委派机制。

双亲委派机制有什么好处呢？
- 安全：我们已经知道，Bootstrap类加载器会加载系统的类库，比如它加载了一个String类，我们自定义的类加载器还想加载一个一模一样的类，那肯定是不行的，因为上层已经加载过的类就不能在下层重新加载了，所以可以保护系统核心库不被篡改。
- 效率：就是这样可以保证一个类只能被加载一次，不会重复加载，可以直接读取已经加载的Class。
### 类加载的时机
- 隐式加载：开发人员并没有刻意的想去加载一个类，或者都并不清楚类加载的概念
- - 创建类的示例
- - 访问类的静态变量
- - 调用类的静态方法
- - 使用反射方式来强制创建某个类或接口对应的java.lang.Class对象
- - 初始化某个类的子类
- 显式加载：
- - 使用LoadClass方法加载
- - 使用forName方法加载
### Android系统中的类加载器
Android平台的类加载器并不是Android特有的，而是从Java当中继承过来的，那么Android类加载器跟Java中的又有什么区别呢？下面我们来一一介绍：
- ClassLoader：一个抽象类，所有的类加载器都直接或间接的继承它
- BootClassLoader：预加载常用的类加载器，它是单例模式的。与Java中的BootStrapClassLoader不同，它并不是由C实现的，而是由Java代码实现的
- BaseDexClassLoader是PathClassLoader、DexClassLoader、InMemoryDexClassLoader的父类，类加载的主要逻辑都是在BaseDexClassLoader完成的。
- SecureClassLoader继承类抽象类ClassLoader，拓展类ClassLoader类，加入类权限方面的功能，加强了安全性，其子类URLClassLoader是用URL路径从网络资源来加载类
- PathClassLoader是Android默认使用的类加载器，一个apk中的Activity等类就是由它来加载的
- DexClassLoader可以加载任意目录下的dex、jar、apk、zip文件，比PathClassLoader更加灵活，是实现插件化、热修复以及dex加壳的重点
- InMemoryDexClassLoader是从内存中直接加载dex，它是在Android8.0以后引入的

> 注意：系统当中常用的Framwork层的类都是由BootClassLoader来加载的，开发一个APP所使用的系统API的类，都是由它加载的，而APP内的类都是由PathClassLoader进行加载的。那我们思考一个问题，加了壳的APP，其真正的dex文件是由哪个类加载器来加载的呢？

### 代码验证类加载器
讲解了这么多关于ClassLoader的内容，你会不会想老师你给我在这胡诌呢？下面我们来用代码验证一下：
![代码验证类加载器](https://mmbiz.qlogo.cn/mmbiz_png/7ePucpwVj77wlk95OAowVja3KfRzerfdnjFm1vvl6VEUEVmHr29aWGHarz7Z2FJyego2iaiax8WWzrszicnm62qdQ/0?wx_fmt=png "代码验证类加载器")

![代码验证类加载器验证结果](https://mmbiz.qlogo.cn/mmbiz_png/7ePucpwVj77wlk95OAowVja3KfRzerfdfSnYC1ia39sxnuiav4uJPb5stPNkPyR31icnFRSMZowyCUNibla1703uxA/0?wx_fmt=png "代码验证类加载器验证结果")
> 我们可以清楚的看到，我们的MainActivity类是由PathClassLoader进行加载的，且PathClassLoader的父类加载器是BootClassLoader，这里需要搞清楚，可能有的同学会问前面不是说PathClassLoader的父类不是BaseDexClassLoader吗？要搞清楚继承跟上文所说的父亲并不是同一个概念。而String类则是由BootClassLoader来加载的，BootClassLoader没有父加载器毋庸置疑。

> 上文我们已经介绍过双亲委派机制了，上面这个例子咱们是获取了MainActivity类的加载器PathClassLoader，String类加载器BootClassLoader，那我们想一下，如果用BootClassLoader来加载咱们的MainActivity类可以吗？使用PathClassLoader来加载String类可以吗？如果你明白了双亲委派机制，那么你肯定是知道答案的：PathClassLoader可以加载String类，而BootClassLoader不可以加载MainActivity类，会抛出常见的ClassNotFoundExcetion异常，可以自己动手实现一下是不是如我所说。提示：想要使用指定ClassLoader来加载一个类，只需要调用ClassLoader实例的loadClass方法，name参数就是该类的全类名如：java.lang.String
 
### 动态加载-DexClassLoader
接下来我们来介绍DexClassLoader类，从名字中可以看出，它就是用来加载dex的，目的很明确。它继承自BaseDexClassLoader，只有一个构造方法，我们来看一下它构造方法的参数：
- dexPath：要加载的目标文件所在的目录，装载器将从路径中寻找指定的目标类。目标文件则可以是dex、jar、apk等文件
- optimizedDirectory：优化目录，这个参数可以看到，4.4版本以下使用，4.4以上系统版本中没有使用到这个参数，暂时忽略。
- librarySearchPath：目标类中使用的C/C++库
- parent：父加载器，一般传当前类的加载器

> 下面同学们请按照我们课程给出的案例，自己动手跟着视频来实现一个动态加载dex文件的Demo，并自己打印一下自己动态加载dex的ClassLoader继承关系，看看其有什么特点。如何得到一个ClassLoader加载了哪些类，并彻底搞懂ClassLoader。

>想了解更多脱壳王的内容请扫码查看详情

![脱壳王广告](https://mmbiz.qlogo.cn/mmbiz_png/7ePucpwVj77wlk95OAowVja3KfRzerfdyiatKpkPfRglTMPTTVvfIvPwvlLMicQInUlb3cofugfj0SZmAACv1QBg/0?wx_fmt=png "脱壳王广告")








