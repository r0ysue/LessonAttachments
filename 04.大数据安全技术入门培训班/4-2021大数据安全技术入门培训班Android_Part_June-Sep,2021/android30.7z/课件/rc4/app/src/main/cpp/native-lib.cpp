#include <jni.h>
#include <string>
#include <stdlib.h>

using namespace std;

static const char base64en[] = {
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H',  'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',  'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X',   'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f','g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v',  'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/'
};

void rc4_init(char s[256], char *pwd, size_t strlen);

void rc4_enc(char s[256], char *data, int len);

extern "C" JNIEXPORT jstring JNICALL
Java_com_dta_rc4_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    std::string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}

void base64_enc(char *data, int len, char *out){
    int index = 0;
    char last_c = 0;
    char c = 0;
    for (int i = 0; i < len; ++i) {
        c = data[i];
        switch (i % 3) {
            case 0:
                out[index++] = base64en[(c >> 2) & 0x3f ];
                break;
            case 1:
                out[index++] = base64en[((last_c & 0x3) << 4) | ((c >> 4) & 0xf )];
                break;
            case 2:
                out[index++] = base64en[( ( last_c & 0xf ) << 2 ) | ((c >> 6 ) & 0x3)];
                out[index++] = base64en[c & 0x3f];
                break;

        }
        last_c = c;
    }
    if(len % 3 == 1){
        out[index++] = base64en[(c & 0x3) << 4];
        out[index++] = '=';
        out[index++] = '=';
    } else if (len % 3 == 2){
        out[index++] = base64en[( c & 0xf ) << 2];
        out[index++] = '=';
    }
}

void rc4_init(char S[256], char *K, size_t len) {
    char T[256] = {0};
    for (int i = 0; i < 256; ++i) {
        S[i] = i;
        T[i] = K[i % len];
    }
    int  j = 0;
    for (int i = 0 ; i < 256 ; i++){
        j = (j + S[i] + T[i]) % 256;
        swap(S[i] , S[j]);
    }
}


void rc4_enc(char S[256], char *data, int len) {
    int i = 0 , j = 0;
    for (int k = 0; k < len; ++k) {
        i = (i + 1) % 256;
        j = (j + S[i]) % 256;
        swap(S[i] , S[j]);
        int t = (S[i] + S[j]) % 256;
        *(data + k ) ^= S[t];
    }
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_dta_rc4_MainActivity_rc4(JNIEnv *env, jobject thiz, jbyteArray data) {
    jbyte *t_data = env->GetByteArrayElements(data,0);
    env->ReleaseByteArrayElements(data,t_data,0);
    char *c_data = reinterpret_cast<char *>(t_data);
    int len = env->GetArrayLength(data);
    char S[256] = {0};
    char *pwd = "123456";
    rc4_init(S,pwd,strlen(pwd));
    rc4_enc(S,c_data,len);
    char result[100] = {0};
    base64_enc(c_data,len,result);
    return env->NewStringUTF(result);
}

