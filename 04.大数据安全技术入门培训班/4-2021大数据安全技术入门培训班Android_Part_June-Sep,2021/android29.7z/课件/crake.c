#include <stdio.h>
#include <string.h>
static const char base64en[] = {
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H',  'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',  'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X',   'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f','g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v',  'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/'
};
void base64_enc(char *data, int len, char *out){
    int index = 0;
    char last_c = 0;
    char c = 0;
    for (int i = 0; i < len; ++i) {
        c = data[i];
        switch (i % 3) {
            case 0:
                out[index++] = base64en[(c >> 2) & 0x3f ];
                break;
            case 1:
                out[index++] = base64en[((last_c & 0x3) << 4) | ((c >> 4) & 0xf )];
                break;
            case 2:
               out[index++] = base64en[( ( last_c & 0xf ) << 2 ) | ((c >> 6 ) & 0x3)];
                out[index++] = base64en[c & 0x3f];
                break;

        }
        last_c = c;
    }
    if(len % 3 == 1){
        out[index++] = base64en[(c & 0x3) << 4];
        out[index++] = '=';
        out[index++] = '=';
    } else if (len % 3 == 2){
        out[index++] = base64en[( c & 0xf ) << 2];
        out[index++] = '=';
    }
}

int main(){
    char *uname = "dtadta";
    int len_uname = strlen(uname);
    char enc_uname[20] = {0};
    char **v6;
    int v7;
    int v11[5] = {0}; // [sp+18h] [bp-458h] BYREF
    int v12[5] = {0};

    for (size_t i = 0; i != 16; ++i)
    {
        v6 = &enc_uname[i];
        v7 = (unsigned int)uname[i % len_uname] * (i + 20160126) * len_uname;
        *(int *)v6 += v7;
    }
    
    for (size_t j = 0; j != 5; ++j )
    {
        v11[j] = *(int *)&enc_uname[j * 4] / 10;
    }

    v12[0] = v11[2] + v11[2] + v11[3];
    v12[1] = 3 * v11[2] - v11[4];
    v12[2] = v11[0] + v11[1]  + v11[0];
    v12[3] = v11[2] + v11[3];
    v12[4] = v11[0] + v11[1];

    char plainText[1052] = {0};
    for (size_t j = 0; j != 5; ++j )
    {
        *(int *)&plainText[j * 4] = v12[j];
    }
    char out[100] = {0};
    
    base64_enc(plainText, strlen(plainText), out);
    printf("password: %s\n",out);
    return 0;
}