function sub_1498(data){
    var base = Module.findBaseAddress("libCheckRegister.so")
    var func_addr = base.add(0x1499);
    var func = new NativeFunction(func_addr,'int',['pointer','pointer'])
    var arg1 = Memory.alloc(100)
    var arg2 = Memory.alloc(100)
    ptr(arg2).writeUtf8String(data)
    var len = func(arg1,arg2)
    console.log(hexdump(arg1))
    console.log(len)

}

