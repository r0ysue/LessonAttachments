package com.dta.dtawallpaper;

import org.junit.Test;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() throws NoSuchAlgorithmException {
        System.out.println(md5(("123")));
    }



    public String md5(String data) throws NoSuchAlgorithmException {
        MessageDigest md5 = MessageDigest.getInstance("md5");
        byte[] digest = md5.digest(data.getBytes());
        StringBuilder sb = new StringBuilder();
        for (byte b : digest){
            if (b < 0){
                b = (byte) -b;
            }
            String hex = Integer.toHexString(b);
            if (hex.length() < 2){
                sb.append("0");
            }
            sb.append(hex);
        }
        return  sb.toString();
    }
}