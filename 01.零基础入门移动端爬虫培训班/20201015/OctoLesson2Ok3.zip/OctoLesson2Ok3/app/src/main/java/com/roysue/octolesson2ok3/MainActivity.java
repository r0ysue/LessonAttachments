package com.roysue.octolesson2ok3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.io.IOException;


import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


public class MainActivity extends AppCompatActivity {

    private static String TAG = "learnokhttp";

    public static final String requestUrl = "http://www.kuaidi100.com/query?type=yuantong&postid=11111111111";

    // 全局只使用这一个拦截器
    public static final OkHttpClient client = new OkHttpClient.Builder()
            .addNetworkInterceptor(new LoggingInterceptor())
            .build();

    Request request = new Request.Builder()
            .url(requestUrl)
            .build();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // 定位发送请求按钮
        Button btn = findViewById(R.id.mybtn);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 发起异步请求
                client.newCall(request).enqueue(new Callback() {
                                                    @Override
                                                    public void onFailure(Call call, IOException e) {
                                                        call.cancel();
                                                    }

                                                    @Override
                                                    public void onResponse(Call call, Response response) throws IOException {

                                                        //打印输出
                                                        Log.d(TAG,  response.body().string());

                                                    }
                                                }
                );

            }
        });
    }

}