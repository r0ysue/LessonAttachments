package com.roysue.octolesson2ok3;
import android.util.Log;
import java.io.IOException;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

class LoggingInterceptor implements Interceptor {

    // TAG即为日志打印时的标签
    private static String TAG = "learnokhttp";

    @Override public Response intercept(Interceptor.Chain chain) throws IOException {

        Request request = chain.request();
        Log.i(TAG, "请求URL："+String.valueOf(request.url())+"\n");
        Log.i(TAG, "请求headers："+"\n"+String.valueOf(request.headers())+"\n");

        Response response = chain.proceed(request);

        return response;
    }

}